package com.divyayatra.controller;

import com.divyayatra.model.Temple;
import com.divyayatra.service.TempleService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/temples")
@CrossOrigin(origins = "*")
public class TempleController {

    private final TempleService templeService;

    public TempleController(TempleService templeService) {
        this.templeService = templeService;
    }

    @GetMapping
    public ResponseEntity<List<Temple>> getAllTemples(@RequestParam(required = false) String state) {
        if (state != null && !state.isBlank()) {
            return ResponseEntity.ok(templeService.getTemplesByState(state));
        }
        return ResponseEntity.ok(templeService.getAllTemples());
    }

    @GetMapping("/states")
    public ResponseEntity<List<String>> getAllStates() {
        return ResponseEntity.ok(templeService.getAllStates());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getTempleDetails(@PathVariable Long id) {
        return ResponseEntity.ok(templeService.getTempleFullDetails(id));
    }

    @GetMapping("/{id}/availability")
    public ResponseEntity<List<Map<String, Object>>> getAvailability(
            @PathVariable Long id,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(templeService.getLiveAvailability(id, date));
    }
}
