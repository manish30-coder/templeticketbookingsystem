-- ===================================================================
-- DIVYA YATRA: Unified Temple Ticket Reservation Platform
-- File: 01_schema.sql
-- Description: Core Relational DDL (Tables, Constraints, Indexes)
-- Target RDBMS: MySQL 8.x / 9.x
-- ===================================================================

USE divyayatra_db;

-- 1. Users & RBAC Accounts
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('DEVOTEE', 'STAFF', 'ADMIN') NOT NULL DEFAULT 'DEVOTEE',
    id_proof_type VARCHAR(30) NULL,
    id_proof_number VARCHAR(50) NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_email (email),
    INDEX idx_user_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Temples Master
CREATE TABLE IF NOT EXISTS temples (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    temple_code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    state VARCHAR(80) NOT NULL,
    city VARCHAR(80) NOT NULL,
    deity VARCHAR(120) NOT NULL,
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    contact_phone VARCHAR(30),
    contact_email VARCHAR(100),
    image_url VARCHAR(255),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_temple_state (state),
    INDEX idx_temple_code (temple_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Darshan Categories Master
CREATE TABLE IF NOT EXISTS darshan_types (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Temple-Darshan Configuration (Rates, Capacity rules)
CREATE TABLE IF NOT EXISTS temple_darshan (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    temple_id BIGINT NOT NULL,
    darshan_type_id BIGINT NOT NULL,
    base_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    max_devotees_per_booking INT NOT NULL DEFAULT 6,
    rules TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_td_temple FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE RESTRICT,
    CONSTRAINT fk_td_darshan FOREIGN KEY (darshan_type_id) REFERENCES darshan_types(id) ON DELETE RESTRICT,
    CONSTRAINT uq_temple_darshan UNIQUE (temple_id, darshan_type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Time Slots Master
CREATE TABLE IF NOT EXISTS time_slots (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    temple_id BIGINT NOT NULL,
    slot_name VARCHAR(80) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_ts_temple FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE,
    CONSTRAINT uq_temple_slot UNIQUE (temple_id, start_time, end_time),
    INDEX idx_ts_temple (temple_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Slot Inventory & Real-Time Capacity Tracking (Concurrency Critical)
CREATE TABLE IF NOT EXISTS slot_inventory (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    temple_id BIGINT NOT NULL,
    darshan_type_id BIGINT NOT NULL,
    slot_id BIGINT NOT NULL,
    reservation_date DATE NOT NULL,
    total_capacity INT NOT NULL,
    reserved_count INT NOT NULL DEFAULT 0,
    version INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_si_temple FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE RESTRICT,
    CONSTRAINT fk_si_darshan FOREIGN KEY (darshan_type_id) REFERENCES darshan_types(id) ON DELETE RESTRICT,
    CONSTRAINT fk_si_slot FOREIGN KEY (slot_id) REFERENCES time_slots(id) ON DELETE RESTRICT,
    CONSTRAINT uq_slot_inventory UNIQUE (temple_id, darshan_type_id, slot_id, reservation_date),
    CONSTRAINT chk_capacity_limits CHECK (reserved_count >= 0 AND reserved_count <= total_capacity),
    INDEX idx_slot_inv_lookup (temple_id, reservation_date, darshan_type_id, slot_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Bookings Master
CREATE TABLE IF NOT EXISTS bookings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(30) NOT NULL UNIQUE,
    user_id BIGINT NOT NULL,
    temple_id BIGINT NOT NULL,
    darshan_type_id BIGINT NOT NULL,
    slot_id BIGINT NOT NULL,
    reservation_date DATE NOT NULL,
    total_devotees INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    booking_status ENUM('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED') NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_bk_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_bk_temple FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE RESTRICT,
    CONSTRAINT fk_bk_darshan FOREIGN KEY (darshan_type_id) REFERENCES darshan_types(id) ON DELETE RESTRICT,
    CONSTRAINT fk_bk_slot FOREIGN KEY (slot_id) REFERENCES time_slots(id) ON DELETE RESTRICT,
    INDEX idx_bk_ref (booking_reference),
    INDEX idx_bk_user (user_id, booking_status),
    INDEX idx_bk_temple_date (temple_id, reservation_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Booking Devotees (Individual Devotee Records)
CREATE TABLE IF NOT EXISTS booking_devotees (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_id BIGINT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender ENUM('MALE', 'FEMALE', 'OTHER') NOT NULL,
    id_proof_type VARCHAR(30) NOT NULL,
    id_proof_number VARCHAR(50) NOT NULL,
    token_number VARCHAR(40) NOT NULL,
    CONSTRAINT fk_bd_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    INDEX idx_bd_booking (booking_id),
    INDEX idx_bd_token (token_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Payments (Transactional Audit)
CREATE TABLE IF NOT EXISTS payments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_id BIGINT NOT NULL UNIQUE,
    transaction_reference VARCHAR(80) NOT NULL UNIQUE,
    payment_method VARCHAR(40) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_status ENUM('INITIATED', 'SUCCESS', 'FAILED', 'REFUNDED') NOT NULL DEFAULT 'INITIATED',
    paid_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pay_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Cancellations (Audit and Capacity Restoration Ledger)
CREATE TABLE IF NOT EXISTS cancellations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_id BIGINT NOT NULL UNIQUE,
    cancelled_by BIGINT NOT NULL,
    reason TEXT NOT NULL,
    refund_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    cancelled_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_can_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    CONSTRAINT fk_can_user FOREIGN KEY (cancelled_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Festival & Special Occasion Schedules
CREATE TABLE IF NOT EXISTS festival_events (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    temple_id BIGINT NOT NULL,
    festival_name VARCHAR(150) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    description TEXT,
    is_booking_restricted BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_fe_temple FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE,
    INDEX idx_fe_dates (temple_id, start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
