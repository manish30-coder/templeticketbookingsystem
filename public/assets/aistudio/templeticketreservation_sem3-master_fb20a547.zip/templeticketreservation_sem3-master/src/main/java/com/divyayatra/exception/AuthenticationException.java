package com.divyayatra.exception;

public class AuthenticationException extends DivyaYatraException {
    public AuthenticationException(String message) {
        super(message, 401);
    }
}
