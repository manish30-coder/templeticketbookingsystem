package com.divyayatra.dto;

public class AuthResponse {
    private Long userId;
    private String fullName;
    private String email;
    private String role;
    private String dashboardRoute;
    private String token; // Academic demonstration bearer token
    private String message;

    public AuthResponse() {}

    public AuthResponse(Long userId, String fullName, String email, String role, String dashboardRoute, String token, String message) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.dashboardRoute = dashboardRoute;
        this.token = token;
        this.message = message;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDashboardRoute() {
        return dashboardRoute;
    }

    public void setDashboardRoute(String dashboardRoute) {
        this.dashboardRoute = dashboardRoute;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
