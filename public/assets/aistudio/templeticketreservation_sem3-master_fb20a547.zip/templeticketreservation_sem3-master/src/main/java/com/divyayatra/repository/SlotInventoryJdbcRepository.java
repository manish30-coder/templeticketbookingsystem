package com.divyayatra.repository;

import com.divyayatra.model.SlotInventory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class SlotInventoryJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public SlotInventoryJdbcRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<SlotInventory> inventoryRowMapper = (rs, rowNum) -> {
        SlotInventory inv = new SlotInventory();
        inv.setId(rs.getLong("id"));
        inv.setTempleId(rs.getLong("temple_id"));
        inv.setDarshanTypeId(rs.getLong("darshan_type_id"));
        inv.setSlotId(rs.getLong("slot_id"));
        Date resDate = rs.getDate("reservation_date");
        if (resDate != null) inv.setReservationDate(resDate.toLocalDate());
        inv.setTotalCapacity(rs.getInt("total_capacity"));
        inv.setReservedCount(rs.getInt("reserved_count"));
        inv.setVersion(rs.getInt("version"));
        return inv;
    };

    /**
     * Query real-time availability from database view vw_temple_live_availability
     * Demonstrates DBMS Unit I: Views and aggregate calculations in SQL
     */
    public List<Map<String, Object>> findLiveAvailability(Long templeId, LocalDate date) {
        String sql = "SELECT * FROM vw_temple_live_availability " +
                "WHERE temple_id = ? AND reservation_date = ? " +
                "ORDER BY start_time ASC, base_price ASC";
        return jdbcTemplate.queryForList(sql, templeId, Date.valueOf(date));
    }

    public Optional<SlotInventory> findSlotInventory(Long templeId, Long darshanTypeId, Long slotId, LocalDate date) {
        String sql = "SELECT * FROM slot_inventory " +
                "WHERE temple_id = ? AND darshan_type_id = ? AND slot_id = ? AND reservation_date = ?";
        List<SlotInventory> results = jdbcTemplate.query(sql, inventoryRowMapper,
                templeId, darshanTypeId, slotId, Date.valueOf(date));
        return results.stream().findFirst();
    }

    public boolean updateCapacity(Long inventoryId, int newCapacity) {
        String sql = "UPDATE slot_inventory SET total_capacity = ?, version = version + 1 WHERE id = ?";
        return jdbcTemplate.update(sql, newCapacity, inventoryId) > 0;
    }

    public boolean createOrUpdateInventory(Long templeId, Long darshanTypeId, Long slotId, LocalDate date, int capacity) {
        String sql = "INSERT INTO slot_inventory (temple_id, darshan_type_id, slot_id, reservation_date, total_capacity, reserved_count) " +
                "VALUES (?, ?, ?, ?, ?, 0) " +
                "ON DUPLICATE KEY UPDATE total_capacity = VALUES(total_capacity)";
        int rows = jdbcTemplate.update(sql, templeId, darshanTypeId, slotId, Date.valueOf(date), capacity);
        return rows > 0;
    }
}
