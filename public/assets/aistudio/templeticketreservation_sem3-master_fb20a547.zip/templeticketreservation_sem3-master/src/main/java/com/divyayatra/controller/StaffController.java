package com.divyayatra.controller;

import com.divyayatra.model.BookingDevotee;
import com.divyayatra.repository.BookingJdbcRepository;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/staff")
@CrossOrigin(origins = "*")
public class StaffController {

    private final BookingJdbcRepository bookingRepository;

    public StaffController(BookingJdbcRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @GetMapping("/lookup/{reference}")
    public ResponseEntity<Map<String, Object>> lookupTicket(@PathVariable String reference) {
        Map<String, Object> booking = bookingRepository.findDetailedBookingByReference(reference)
                .orElse(null);
        if (booking == null) {
            return ResponseEntity.notFound().build();
        }
        Long bookingId = (Long) booking.get("booking_id");
        List<BookingDevotee> devotees = bookingRepository.findDevoteesForBooking(bookingId);

        Map<String, Object> response = new HashMap<>(booking);
        response.put("devotees", devotees);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/temple-manifest")
    public ResponseEntity<List<Map<String, Object>>> getTempleManifest(
            @RequestParam Long templeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        // Calls stored procedure with SQL cursor
        List<Map<String, Object>> manifest = bookingRepository.executeDailyManifestCursor(templeId, date);
        return ResponseEntity.ok(manifest);
    }

    @GetMapping("/daily-bookings")
    public ResponseEntity<List<Map<String, Object>>> getDailyBookings(
            @RequestParam Long templeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(bookingRepository.findDetailedBookingsByTempleAndDate(templeId, date));
    }
}
