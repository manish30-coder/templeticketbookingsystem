package com.divyayatra.mongodb;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import org.springframework.data.mongodb.core.mapping.Field;

/**
 * FestivalAnnouncement document stored in MongoDB.
 * Demonstrates NoSQL document for time-bound announcements, advisories, and circulars.
 */
@Document(collection = "festival_announcements")
public class FestivalAnnouncement {

    @Id
    private String id;

    @Field("temple_code")
    private String templeCode;
    private String festival_name;
    private String announcement_title;
    private String content;
    private String effective_from;
    private String effective_to;
    private String priority; // HIGH, MEDIUM, LOW
    private String published_by;

    public FestivalAnnouncement() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTempleCode() {
        return templeCode;
    }

    public void setTempleCode(String templeCode) {
        this.templeCode = templeCode;
    }

    public String getTemple_code() {
        return templeCode;
    }

    public void setTemple_code(String temple_code) {
        this.templeCode = temple_code;
    }

    public String getFestival_name() {
        return festival_name;
    }

    public void setFestival_name(String festival_name) {
        this.festival_name = festival_name;
    }

    public String getAnnouncement_title() {
        return announcement_title;
    }

    public void setAnnouncement_title(String announcement_title) {
        this.announcement_title = announcement_title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getEffective_from() {
        return effective_from;
    }

    public void setEffective_from(String effective_from) {
        this.effective_from = effective_from;
    }

    public String getEffective_to() {
        return effective_to;
    }

    public void setEffective_to(String effective_to) {
        this.effective_to = effective_to;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getPublished_by() {
        return published_by;
    }

    public void setPublished_by(String published_by) {
        this.published_by = published_by;
    }
}
