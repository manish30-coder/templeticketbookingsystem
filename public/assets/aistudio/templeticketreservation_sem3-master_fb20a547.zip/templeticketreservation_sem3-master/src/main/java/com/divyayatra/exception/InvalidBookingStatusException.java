package com.divyayatra.exception;

public class InvalidBookingStatusException extends DivyaYatraException {
    public InvalidBookingStatusException(String message) {
        super(message, 400);
    }
}
