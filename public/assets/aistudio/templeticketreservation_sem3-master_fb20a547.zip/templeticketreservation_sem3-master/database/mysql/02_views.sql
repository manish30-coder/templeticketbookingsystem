-- ===================================================================
-- DIVYA YATRA: Unified Temple Ticket Reservation Platform
-- File: 02_views.sql
-- Description: Database Views (Live Availability, Booking Summary, Revenue)
-- Target RDBMS: MySQL 8.x / 9.x
-- ===================================================================

USE divyayatra_db;

-- 1. View: Real-Time Temple Slot Availability
DROP VIEW IF EXISTS vw_temple_live_availability;
CREATE VIEW vw_temple_live_availability AS
SELECT 
    si.id AS inventory_id,
    t.id AS temple_id,
    t.temple_code,
    t.name AS temple_name,
    t.state AS temple_state,
    t.city AS temple_city,
    dt.id AS darshan_type_id,
    dt.code AS darshan_code,
    dt.name AS darshan_name,
    td.base_price,
    ts.id AS slot_id,
    ts.slot_name,
    ts.start_time,
    ts.end_time,
    si.reservation_date,
    si.total_capacity,
    si.reserved_count,
    (si.total_capacity - si.reserved_count) AS available_seats,
    CASE 
        WHEN (si.total_capacity - si.reserved_count) = 0 THEN 'SOLD_OUT'
        WHEN (si.total_capacity - si.reserved_count) <= (si.total_capacity * 0.2) THEN 'FAST_FILLING'
        ELSE 'AVAILABLE'
    END AS availability_status
FROM slot_inventory si
JOIN temples t ON si.temple_id = t.id
JOIN darshan_types dt ON si.darshan_type_id = dt.id
JOIN temple_darshan td ON (td.temple_id = t.id AND td.darshan_type_id = dt.id)
JOIN time_slots ts ON si.slot_id = ts.id
WHERE t.is_active = TRUE AND dt.is_active = TRUE AND ts.is_active = TRUE;

-- 2. View: Master Booking Summary (Audit & Devotee Pass Lookup)
DROP VIEW IF EXISTS vw_booking_summary_master;
CREATE VIEW vw_booking_summary_master AS
SELECT 
    b.id AS booking_id,
    b.booking_reference,
    b.created_at AS booking_timestamp,
    b.booking_status,
    u.id AS user_id,
    u.full_name AS primary_devotee_name,
    u.email AS user_email,
    u.phone AS user_phone,
    t.id AS temple_id,
    t.temple_code,
    t.name AS temple_name,
    t.city AS temple_city,
    t.state AS temple_state,
    dt.id AS darshan_type_id,
    dt.name AS darshan_name,
    ts.id AS slot_id,
    ts.slot_name,
    ts.start_time,
    ts.end_time,
    b.reservation_date,
    b.total_devotees,
    b.total_amount,
    p.transaction_reference,
    p.payment_method,
    p.payment_status,
    c.reason AS cancellation_reason,
    c.cancelled_at
FROM bookings b
JOIN users u ON b.user_id = u.id
JOIN temples t ON b.temple_id = t.id
JOIN darshan_types dt ON b.darshan_type_id = dt.id
JOIN time_slots ts ON b.slot_id = ts.id
LEFT JOIN payments p ON b.id = p.booking_id
LEFT JOIN cancellations c ON b.id = c.booking_id;

-- 3. View: Temple Booking and Revenue Aggregates
DROP VIEW IF EXISTS vw_temple_revenue_stats;
CREATE VIEW vw_temple_revenue_stats AS
SELECT 
    t.id AS temple_id,
    t.name AS temple_name,
    t.state,
    COUNT(CASE WHEN b.booking_status = 'CONFIRMED' THEN 1 END) AS confirmed_bookings,
    COUNT(CASE WHEN b.booking_status = 'CANCELLED' THEN 1 END) AS cancelled_bookings,
    COALESCE(SUM(CASE WHEN b.booking_status = 'CONFIRMED' THEN b.total_devotees ELSE 0 END), 0) AS total_devotees_served,
    COALESCE(SUM(CASE WHEN b.booking_status = 'CONFIRMED' THEN b.total_amount ELSE 0 END), 0) AS gross_revenue
FROM temples t
LEFT JOIN bookings b ON t.id = b.temple_id
GROUP BY t.id, t.name, t.state;
