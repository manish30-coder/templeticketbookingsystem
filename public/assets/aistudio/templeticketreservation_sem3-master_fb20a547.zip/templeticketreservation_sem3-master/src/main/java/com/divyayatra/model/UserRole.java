package com.divyayatra.model;

/**
 * UserRole enumeration defining role-based access levels.
 */
public enum UserRole {
    DEVOTEE,
    STAFF,
    ADMIN
}
