package com.divyayatra.config;

import com.divyayatra.mongodb.FestivalAnnouncement;
import com.divyayatra.mongodb.FestivalAnnouncementMongoRepository;
import com.divyayatra.mongodb.TempleContent;
import com.divyayatra.mongodb.TempleContentMongoRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * MongoDataInitializer populates the MongoDB collections with rich temple lore
 * and festival announcements on application startup if empty.
 */
@Configuration
public class MongoDataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(MongoDataInitializer.class);

    private final TempleContentMongoRepository templeContentRepo;
    private final FestivalAnnouncementMongoRepository festivalAnnouncementRepo;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public MongoDataInitializer(TempleContentMongoRepository templeContentRepo,
                                FestivalAnnouncementMongoRepository festivalAnnouncementRepo) {
        this.templeContentRepo = templeContentRepo;
        this.festivalAnnouncementRepo = festivalAnnouncementRepo;
    }

    @Override
    public void run(String... args) {
        try {
            if (templeContentRepo.count() == 0) {
                log.info("MongoDB 'temple_content' collection is empty. Seeding rich cultural lore...");
                File file = new File("database/mongodb/01_temple_content.json");
                if (file.exists()) {
                    List<TempleContent> contents = objectMapper.readValue(file, new TypeReference<>() {});
                    templeContentRepo.saveAll(contents);
                    log.info("Successfully seeded {} temple documents into MongoDB 'temple_content'", contents.size());
                } else {
                    log.warn("Seed file not found at: database/mongodb/01_temple_content.json");
                }
            }

            if (festivalAnnouncementRepo.count() == 0) {
                log.info("MongoDB 'festival_announcements' collection is empty. Seeding announcements...");
                File file = new File("database/mongodb/02_festival_announcements.json");
                if (file.exists()) {
                    List<FestivalAnnouncement> festivals = objectMapper.readValue(file, new TypeReference<>() {});
                    festivalAnnouncementRepo.saveAll(festivals);
                    log.info("Successfully seeded {} festival documents into MongoDB 'festival_announcements'", festivals.size());
                }
            }
        } catch (Exception e) {
            log.error("Error during MongoDB data initialization: {}", e.getMessage(), e);
        }
    }
}
