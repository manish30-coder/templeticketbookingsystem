package com.divyayatra.exception;

public class SlotCapacityExceededException extends DivyaYatraException {
    public SlotCapacityExceededException(String message) {
        super(message, 409);
    }
}
