package com.divyayatra.exception;

public class InventoryNotFoundException extends DivyaYatraException {
    public InventoryNotFoundException(String message) {
        super(message, 404);
    }
}
