package com.divyayatra;

import com.divyayatra.dto.*;
import com.divyayatra.exception.SlotCapacityExceededException;
import com.divyayatra.model.AbstractUser;
import com.divyayatra.model.Temple;
import com.divyayatra.service.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class BackendApiTest {

    @Autowired
    private AuthService authService;

    @Autowired
    private TempleService templeService;

    @Autowired
    private ReservationOperation reservationOperation;

    @Autowired
    private CancellationPolicy cancellationPolicy;

    @Autowired
    private FileExportService fileExportService;

    @Autowired
    private AnalyticsStreamService analyticsStreamService;

    @Test
    @DisplayName("Test 1: Devotee Registration and BCrypt Authentication")
    void testAuthenticationFlow() {
        String testEmail = "test_devotee_" + System.currentTimeMillis() + "@divyayatra.org";
        RegisterRequest regReq = new RegisterRequest();
        regReq.setFullName("Rameshwar Sharma");
        regReq.setEmail(testEmail);
        regReq.setPhone("+91 9123456789");
        regReq.setPassword("SecretPass@123");
        regReq.setIdProofType("AADHAAR");
        regReq.setIdProofNumber("1122-3344-5566");

        AuthResponse regResp = authService.register(regReq);
        assertNotNull(regResp);
        assertEquals("DEVOTEE", regResp.getRole());
        assertEquals("/pages/devotee_dashboard.html", regResp.getDashboardRoute());

        // Test Login
        LoginRequest loginReq = new LoginRequest();
        loginReq.setEmail(testEmail);
        loginReq.setPassword("SecretPass@123");

        AuthResponse loginResp = authService.login(loginReq);
        assertNotNull(loginResp);
        assertEquals(regResp.getUserId(), loginResp.getUserId());
    }

    @Test
    @DisplayName("Test 2: Temple Listing and Hybrid Polyglot Data (MySQL + MongoDB)")
    void testTempleHybridData() {
        List<Temple> temples = templeService.getAllTemples();
        assertFalse(temples.isEmpty(), "Default temples should be loaded");
        assertTrue(temples.size() >= 8, "All 8 default temples should be present");

        // Test Hybrid Details (Temple 1: Tirumala)
        Map<String, Object> details = templeService.getTempleFullDetails(1L);
        assertNotNull(details.get("temple"), "MySQL Temple entity should be present");
        assertNotNull(details.get("darshanTypes"), "MySQL darshan types should be present");
        assertNotNull(details.get("culturalLore"), "MongoDB rich lore document should be present");
    }

    @Test
    @DisplayName("Test 3: Live Slot Availability View Query")
    void testLiveAvailability() {
        List<Map<String, Object>> availability = templeService.getLiveAvailability(1L, LocalDate.now());
        assertNotNull(availability);
        assertFalse(availability.isEmpty(), "Availability records should exist from slot_inventory");
        assertTrue(availability.get(0).containsKey("available_seats"));
        assertTrue(availability.get(0).containsKey("availability_status"));
    }

    @Test
    @DisplayName("Test 4: ACID Smart Reservation, Token Generation, and Cancellation")
    void testReservationAndCancellation() {
        BookingRequest req = new BookingRequest();
        req.setUserId(3L);
        req.setTempleId(2L); // Meenakshi Amman
        req.setDarshanTypeId(2L); // Special Entry
        req.setSlotId(6L); // Forenoon Slot
        req.setReservationDate(LocalDate.now().plusDays(2));
        req.setPaymentMethod("UPI");

        List<DevoteeDto> devotees = new ArrayList<>();
        devotees.add(new DevoteeDto("Subramanian", 45, "MALE", "AADHAAR", "4455-6677-8899"));
        devotees.add(new DevoteeDto("Kalyani", 42, "FEMALE", "AADHAAR", "9988-7766-5544"));
        req.setDevotees(devotees);

        // Execute reservation
        BookingResponse resp = reservationOperation.processReservation(req);
        assertNotNull(resp);
        assertNotNull(resp.getBookingReference());
        assertEquals("CONFIRMED", resp.getBookingStatus());
        assertEquals(2, resp.getDevoteeTokens().size());

        // Test Pass Text Generation (Unit IV Character & Byte stream)
        byte[] passBytes = fileExportService.generateTicketPassFile(resp.getBookingReference());
        assertNotNull(passBytes);
        assertTrue(passBytes.length > 0);
        String passText = new String(passBytes);
        assertTrue(passText.contains("DIVYA YATRA PILGRIMAGE PASS"));
        assertTrue(passText.contains(resp.getBookingReference()));

        // Test Cancellation & Capacity Restoration
        CancelBookingRequest cancelReq = new CancelBookingRequest();
        cancelReq.setBookingId(resp.getBookingId());
        cancelReq.setUserId(3L);
        cancelReq.setReason("Academic automated integration test cancellation");

        boolean cancelled = cancellationPolicy.processCancellation(cancelReq);
        assertTrue(cancelled, "Booking cancellation should succeed");
    }

    @Test
    @DisplayName("Test 5: Overbooking Protection Trigger & Error Handling")
    void testOverbookingProtection() {
        BookingRequest req = new BookingRequest();
        req.setUserId(3L);
        req.setTempleId(1L);
        req.setDarshanTypeId(3L); // VIP Suprabhata (capacity 30)
        req.setSlotId(1L);
        req.setReservationDate(LocalDate.now().plusDays(3));

        // Create a massive list of devotees exceeding capacity
        List<DevoteeDto> devotees = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            devotees.add(new DevoteeDto("Devotee " + i, 30, "MALE", "AADHAAR", "1000-0000-" + i));
        }
        req.setDevotees(devotees);

        // Validation rule ensures max 6 per reservation, preventing flood
        assertThrows(RuntimeException.class, () -> reservationOperation.processReservation(req));
    }

    @Test
    @DisplayName("Test 6: Java Stream API Analytics Demonstration")
    void testStreamAnalytics() {
        var parallelSummaries = analyticsStreamService.extractAllConfirmedReferencesParallel();
        assertNotNull(parallelSummaries);
    }
}
