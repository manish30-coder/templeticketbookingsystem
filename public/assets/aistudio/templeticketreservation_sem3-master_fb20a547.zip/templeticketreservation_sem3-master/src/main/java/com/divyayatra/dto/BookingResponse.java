package com.divyayatra.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class BookingResponse {
    private Long bookingId;
    private String bookingReference;
    private String templeName;
    private String darshanName;
    private String slotName;
    private LocalDate reservationDate;
    private int totalDevotees;
    private BigDecimal totalAmount;
    private String bookingStatus;
    private String transactionReference;
    private List<String> devoteeTokens;
    private String message;

    public BookingResponse() {}

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public String getBookingReference() {
        return bookingReference;
    }

    public void setBookingReference(String bookingReference) {
        this.bookingReference = bookingReference;
    }

    public String getTempleName() {
        return templeName;
    }

    public void setTempleName(String templeName) {
        this.templeName = templeName;
    }

    public String getDarshanName() {
        return darshanName;
    }

    public void setDarshanName(String darshanName) {
        this.darshanName = darshanName;
    }

    public String getSlotName() {
        return slotName;
    }

    public void setSlotName(String slotName) {
        this.slotName = slotName;
    }

    public LocalDate getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDate reservationDate) {
        this.reservationDate = reservationDate;
    }

    public int getTotalDevotees() {
        return totalDevotees;
    }

    public void setTotalDevotees(int totalDevotees) {
        this.totalDevotees = totalDevotees;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public String getTransactionReference() {
        return transactionReference;
    }

    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }

    public List<String> getDevoteeTokens() {
        return devoteeTokens;
    }

    public void setDevoteeTokens(List<String> devoteeTokens) {
        this.devoteeTokens = devoteeTokens;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
