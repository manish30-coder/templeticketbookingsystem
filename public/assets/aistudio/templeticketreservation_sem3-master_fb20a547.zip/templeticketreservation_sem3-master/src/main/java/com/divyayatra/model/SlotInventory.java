package com.divyayatra.model;

import java.time.LocalDate;

public class SlotInventory {
    private Long id;
    private Long templeId;
    private Long darshanTypeId;
    private Long slotId;
    private LocalDate reservationDate;
    private int totalCapacity;
    private int reservedCount;
    private int version;

    public SlotInventory() {}

    public SlotInventory(Long id, Long templeId, Long darshanTypeId, Long slotId,
                         LocalDate reservationDate, int totalCapacity, int reservedCount, int version) {
        this.id = id;
        this.templeId = templeId;
        this.darshanTypeId = darshanTypeId;
        this.slotId = slotId;
        this.reservationDate = reservationDate;
        this.totalCapacity = totalCapacity;
        this.reservedCount = reservedCount;
        this.version = version;
    }

    public int getAvailableSeats() {
        return Math.max(0, this.totalCapacity - this.reservedCount);
    }

    public boolean isAvailable(int requestedSeats) {
        return getAvailableSeats() >= requestedSeats;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTempleId() {
        return templeId;
    }

    public void setTempleId(Long templeId) {
        this.templeId = templeId;
    }

    public Long getDarshanTypeId() {
        return darshanTypeId;
    }

    public void setDarshanTypeId(Long darshanTypeId) {
        this.darshanTypeId = darshanTypeId;
    }

    public Long getSlotId() {
        return slotId;
    }

    public void setSlotId(Long slotId) {
        this.slotId = slotId;
    }

    public LocalDate getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDate reservationDate) {
        this.reservationDate = reservationDate;
    }

    public int getTotalCapacity() {
        return totalCapacity;
    }

    public void setTotalCapacity(int totalCapacity) {
        this.totalCapacity = totalCapacity;
    }

    public int getReservedCount() {
        return reservedCount;
    }

    public void setReservedCount(int reservedCount) {
        this.reservedCount = reservedCount;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
}
