package com.divyayatra.controller;

import com.divyayatra.dto.AuthResponse;
import com.divyayatra.dto.LoginRequest;
import com.divyayatra.dto.RegisterRequest;
import com.divyayatra.model.AbstractUser;
import com.divyayatra.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        AuthResponse response = authService.register(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        AuthResponse response = authService.login(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<AbstractUser> getUserProfile(@PathVariable Long id) {
        AbstractUser user = authService.getUserById(id);
        return ResponseEntity.ok(user);
    }
}
