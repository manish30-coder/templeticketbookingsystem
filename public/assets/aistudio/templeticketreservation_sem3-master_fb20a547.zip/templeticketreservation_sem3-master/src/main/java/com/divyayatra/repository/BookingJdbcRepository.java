package com.divyayatra.repository;

import com.divyayatra.dto.DevoteeDto;
import com.divyayatra.model.Booking;
import com.divyayatra.model.BookingDevotee;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.*;

@Repository
public class BookingJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public BookingJdbcRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Booking> bookingRowMapper = (rs, rowNum) -> {
        Booking b = new Booking();
        b.setId(rs.getLong("id"));
        b.setBookingReference(rs.getString("booking_reference"));
        b.setUserId(rs.getLong("user_id"));
        b.setTempleId(rs.getLong("temple_id"));
        b.setDarshanTypeId(rs.getLong("darshan_type_id"));
        b.setSlotId(rs.getLong("slot_id"));
        Date rDate = rs.getDate("reservation_date");
        if (rDate != null) b.setReservationDate(rDate.toLocalDate());
        b.setTotalDevotees(rs.getInt("total_devotees"));
        b.setTotalAmount(rs.getBigDecimal("total_amount"));
        b.setBookingStatus(rs.getString("booking_status"));
        Timestamp cAt = rs.getTimestamp("created_at");
        if (cAt != null) b.setCreatedAt(cAt.toLocalDateTime());
        Timestamp uAt = rs.getTimestamp("updated_at");
        if (uAt != null) b.setUpdatedAt(uAt.toLocalDateTime());
        return b;
    };

    /**
     * Executes the ACID Stored Procedure sp_reserve_tickets.
     * Demonstrates DBMS Unit II (Stored Procedures, OUT parameters, ACID guarantees).
     */
    public Map<String, Object> executeReserveTicketsProcedure(Long userId, Long templeId, Long darshanTypeId,
                                                             Long slotId, LocalDate reservationDate,
                                                             int devoteeCount, String paymentMethod) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("sp_reserve_tickets");

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_user_id", userId)
                .addValue("p_temple_id", templeId)
                .addValue("p_darshan_type_id", darshanTypeId)
                .addValue("p_slot_id", slotId)
                .addValue("p_reservation_date", Date.valueOf(reservationDate))
                .addValue("p_devotee_count", devoteeCount)
                .addValue("p_payment_method", paymentMethod != null ? paymentMethod : "UPI");

        return jdbcCall.execute(params);
    }

    /**
     * Batch inserts individual devotees. No comma-separated columns!
     */
    public List<String> saveBookingDevotees(Long bookingId, String bookingRef, List<DevoteeDto> devotees) {
        String sql = "INSERT INTO booking_devotees (booking_id, full_name, age, gender, id_proof_type, id_proof_number, token_number) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        List<String> tokens = new ArrayList<>();

        int index = 1;
        for (DevoteeDto d : devotees) {
            String token = String.format("TK-%s-%02d", bookingRef.substring(bookingRef.length() - 6), index++);
            tokens.add(token);
            jdbcTemplate.update(sql,
                    bookingId,
                    d.getFullName(),
                    d.getAge(),
                    d.getGender(),
                    d.getIdProofType(),
                    d.getIdProofNumber(),
                    token
            );
        }
        return tokens;
    }

    /**
     * Executes Stored Procedure sp_cancel_booking with atomic capacity restoration.
     */
    public Map<String, Object> executeCancelBookingProcedure(Long bookingId, Long userId, String reason) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("sp_cancel_booking");

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_booking_id", bookingId)
                .addValue("p_user_id", userId)
                .addValue("p_reason", reason);

        return jdbcCall.execute(params);
    }

    public Optional<Booking> findById(Long id) {
        String sql = "SELECT * FROM bookings WHERE id = ?";
        List<Booking> results = jdbcTemplate.query(sql, bookingRowMapper, id);
        return results.stream().findFirst();
    }

    public Optional<Booking> findByReference(String reference) {
        String sql = "SELECT * FROM bookings WHERE booking_reference = ?";
        List<Booking> results = jdbcTemplate.query(sql, bookingRowMapper, reference);
        return results.stream().findFirst();
    }

    public List<Map<String, Object>> findDetailedBookingsByUserId(Long userId) {
        String sql = "SELECT * FROM vw_booking_summary_master WHERE user_id = ? ORDER BY booking_timestamp DESC";
        return jdbcTemplate.queryForList(sql, userId);
    }

    public List<Map<String, Object>> findDetailedBookingsByTempleAndDate(Long templeId, LocalDate date) {
        String sql = "SELECT * FROM vw_booking_summary_master WHERE temple_id = ? AND reservation_date = ? ORDER BY start_time ASC";
        return jdbcTemplate.queryForList(sql, templeId, Date.valueOf(date));
    }

    public Optional<Map<String, Object>> findDetailedBookingByReference(String reference) {
        String sql = "SELECT * FROM vw_booking_summary_master WHERE booking_reference = ?";
        List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, reference);
        return list.stream().findFirst();
    }

    public List<BookingDevotee> findDevoteesForBooking(Long bookingId) {
        String sql = "SELECT * FROM booking_devotees WHERE booking_id = ? ORDER BY id ASC";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            BookingDevotee bd = new BookingDevotee();
            bd.setId(rs.getLong("id"));
            bd.setBookingId(rs.getLong("booking_id"));
            bd.setFullName(rs.getString("full_name"));
            bd.setAge(rs.getInt("age"));
            bd.setGender(rs.getString("gender"));
            bd.setIdProofType(rs.getString("id_proof_type"));
            bd.setIdProofNumber(rs.getString("id_proof_number"));
            bd.setTokenNumber(rs.getString("token_number"));
            return bd;
        }, bookingId);
    }

    /**
     * Executes Stored Procedure with explicit SQL Cursor to generate daily manifest
     * Demonstrates DBMS Unit II: Explicit Cursors in MySQL
     */
    public List<Map<String, Object>> executeDailyManifestCursor(Long templeId, LocalDate date) {
        String sql = "CALL sp_generate_daily_manifest(?, ?)";
        return jdbcTemplate.queryForList(sql, templeId, Date.valueOf(date));
    }

    public Map<String, Object> getOverallMetrics() {
        Map<String, Object> metrics = new HashMap<>();

        Long totalBookings = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM bookings", Long.class);
        Long confirmedBookings = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM bookings WHERE booking_status = 'CONFIRMED'", Long.class);
        Long cancelledBookings = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM bookings WHERE booking_status = 'CANCELLED'", Long.class);
        Double totalRevenue = jdbcTemplate.queryForObject("SELECT COALESCE(SUM(total_amount), 0.0) FROM bookings WHERE booking_status = 'CONFIRMED'", Double.class);
        Long totalDevotees = jdbcTemplate.queryForObject("SELECT COALESCE(SUM(total_devotees), 0) FROM bookings WHERE booking_status = 'CONFIRMED'", Long.class);
        Long activeTemples = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM temples WHERE is_active = TRUE", Long.class);
        Long totalUsers = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Long.class);

        metrics.put("totalBookings", totalBookings);
        metrics.put("confirmedBookings", confirmedBookings);
        metrics.put("cancelledBookings", cancelledBookings);
        metrics.put("totalRevenue", totalRevenue);
        metrics.put("totalDevotees", totalDevotees);
        metrics.put("activeTemples", activeTemples);
        metrics.put("totalUsers", totalUsers);

        return metrics;
    }

    public List<Map<String, Object>> getTempleRevenueStats() {
        String sql = "SELECT * FROM vw_temple_revenue_stats ORDER BY gross_revenue DESC";
        return jdbcTemplate.queryForList(sql);
    }
}
