-- ===================================================================
-- DIVYA YATRA: Unified Temple Ticket Reservation Platform
-- File: 03_procedures_triggers.sql
-- Description: Stored Procedures, Functions, Triggers & Cursors
-- Target RDBMS: MySQL 8.x / 9.x
-- ===================================================================

USE divyayatra_db;

DELIMITER $$

-- 1. Trigger: Engine-level Overbooking Prevention
DROP TRIGGER IF EXISTS trg_prevent_overbooking$$
CREATE TRIGGER trg_prevent_overbooking
BEFORE UPDATE ON slot_inventory
FOR EACH ROW
BEGIN
    IF NEW.reserved_count > NEW.total_capacity THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'CONSTRAINED_ERROR: Requested tickets exceed maximum slot capacity.';
    END IF;
    IF NEW.reserved_count < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'CONSTRAINED_ERROR: Reserved ticket count cannot be negative.';
    END IF;
END$$

-- 2. Stored Function: Dynamic Booking Amount Calculation
DROP FUNCTION IF EXISTS fn_calculate_booking_amount$$
CREATE FUNCTION fn_calculate_booking_amount(
    p_temple_id BIGINT,
    p_darshan_type_id BIGINT,
    p_devotee_count INT
) RETURNS DECIMAL(10,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_unit_price DECIMAL(10,2) DEFAULT 0.00;
    
    SELECT base_price INTO v_unit_price
    FROM temple_darshan
    WHERE temple_id = p_temple_id AND darshan_type_id = p_darshan_type_id AND is_active = TRUE
    LIMIT 1;
    
    RETURN (v_unit_price * p_devotee_count);
END$$

-- 3. Stored Procedure: ACID Atomic Smart Ticket Reservation
DROP PROCEDURE IF EXISTS sp_reserve_tickets$$
CREATE PROCEDURE sp_reserve_tickets(
    IN p_user_id BIGINT,
    IN p_temple_id BIGINT,
    IN p_darshan_type_id BIGINT,
    IN p_slot_id BIGINT,
    IN p_reservation_date DATE,
    IN p_devotee_count INT,
    IN p_payment_method VARCHAR(40),
    OUT p_booking_id BIGINT,
    OUT p_booking_reference VARCHAR(30),
    OUT p_status_code INT,
    OUT p_status_message VARCHAR(255)
)
proc_label: BEGIN
    DECLARE v_curr_reserved INT DEFAULT 0;
    DECLARE v_total_capacity INT DEFAULT 0;
    DECLARE v_inventory_id BIGINT DEFAULT NULL;
    DECLARE v_unit_price DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_total_amount DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_ref VARCHAR(30);
    DECLARE v_tx_ref VARCHAR(80);

    DECLARE v_err_code INT DEFAULT 0;
    DECLARE v_err_msg VARCHAR(255) DEFAULT '';

    -- Declare error handler to roll back in case of SQL exceptions
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1
            v_err_code = MYSQL_ERRNO, v_err_msg = MESSAGE_TEXT;
        ROLLBACK;
        SET p_booking_id = NULL;
        SET p_booking_reference = NULL;
        SET p_status_code = 500;
        SET p_status_message = CONCAT('DB_ERROR [', v_err_code, ']: ', v_err_msg);
    END;

    -- Validate input count
    IF p_devotee_count <= 0 THEN
        SET p_status_code = 400;
        SET p_status_message = 'VALIDATION_ERROR: Devotee count must be at least 1.';
        LEAVE proc_label;
    END IF;

    START TRANSACTION;

    -- Step 1: Pessimistic Row Lock (Two-Phase Locking 2PL) on slot inventory
    SELECT id, total_capacity, reserved_count
    INTO v_inventory_id, v_total_capacity, v_curr_reserved
    FROM slot_inventory
    WHERE temple_id = p_temple_id 
      AND darshan_type_id = p_darshan_type_id 
      AND slot_id = p_slot_id 
      AND reservation_date = p_reservation_date
    FOR UPDATE;

    -- Check if inventory record exists
    IF v_inventory_id IS NULL THEN
        ROLLBACK;
        SET p_status_code = 404;
        SET p_status_message = 'INVENTORY_NOT_FOUND: No slot inventory exists for the selected date and slot.';
        LEAVE proc_label;
    END IF;

    -- Check capacity availability
    IF (v_curr_reserved + p_devotee_count) > v_total_capacity THEN
        ROLLBACK;
        SET p_status_code = 409;
        SET p_status_message = 'CAPACITY_EXCEEDED: Insufficient capacity available for this slot.';
        LEAVE proc_label;
    END IF;

    -- Calculate amount
    SET v_total_amount = fn_calculate_booking_amount(p_temple_id, p_darshan_type_id, p_devotee_count);

    -- Step 2: Atomic Capacity Increment
    UPDATE slot_inventory
    SET reserved_count = reserved_count + p_devotee_count,
        version = version + 1
    WHERE id = v_inventory_id;

    -- Step 3: Generate unique booking & payment references
    SET v_ref = CONCAT('DY-', DATE_FORMAT(p_reservation_date, '%y%m%d'), '-', UPPER(SUBSTRING(REPLACE(UUID(), '-', ''), 1, 6)));
    SET v_tx_ref = CONCAT('TXN-', UPPER(SUBSTRING(REPLACE(UUID(), '-', ''), 1, 12)));

    -- Step 4: Insert Booking Record
    INSERT INTO bookings (
        booking_reference, user_id, temple_id, darshan_type_id, slot_id,
        reservation_date, total_devotees, total_amount, booking_status
    ) VALUES (
        v_ref, p_user_id, p_temple_id, p_darshan_type_id, p_slot_id,
        p_reservation_date, p_devotee_count, v_total_amount, 'CONFIRMED'
    );
    SET p_booking_id = LAST_INSERT_ID();
    SET p_booking_reference = v_ref;

    -- Step 5: Insert Payment Record
    INSERT INTO payments (
        booking_id, transaction_reference, payment_method, amount, payment_status
    ) VALUES (
        p_booking_id, v_tx_ref, p_payment_method, v_total_amount, 'SUCCESS'
    );

    COMMIT;

    SET p_status_code = 200;
    SET p_status_message = 'SUCCESS: Reservation successfully confirmed.';
END$$

-- 4. Stored Procedure: Cancellation with Atomic Capacity Restoration
DROP PROCEDURE IF EXISTS sp_cancel_booking$$
CREATE PROCEDURE sp_cancel_booking(
    IN p_booking_id BIGINT,
    IN p_user_id BIGINT,
    IN p_reason TEXT,
    OUT p_status_code INT,
    OUT p_status_message VARCHAR(255)
)
proc_label: BEGIN
    DECLARE v_status VARCHAR(30);
    DECLARE v_temple_id BIGINT;
    DECLARE v_darshan_type_id BIGINT;
    DECLARE v_slot_id BIGINT;
    DECLARE v_res_date DATE;
    DECLARE v_devotees INT;
    DECLARE v_amount DECIMAL(10,2);
    DECLARE v_inventory_id BIGINT;

    DECLARE v_err_code INT DEFAULT 0;
    DECLARE v_err_msg VARCHAR(255) DEFAULT '';

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1
            v_err_code = MYSQL_ERRNO, v_err_msg = MESSAGE_TEXT;
        ROLLBACK;
        SET p_status_code = 500;
        SET p_status_message = CONCAT('DB_ERROR [', v_err_code, ']: ', v_err_msg);
    END;

    START TRANSACTION;

    -- Fetch and lock booking
    SELECT booking_status, temple_id, darshan_type_id, slot_id, reservation_date, total_devotees, total_amount
    INTO v_status, v_temple_id, v_darshan_type_id, v_slot_id, v_res_date, v_devotees, v_amount
    FROM bookings
    WHERE id = p_booking_id
    FOR UPDATE;

    IF v_status IS NULL THEN
        ROLLBACK;
        SET p_status_code = 404;
        SET p_status_message = 'BOOKING_NOT_FOUND: Specified booking ID does not exist.';
        LEAVE proc_label;
    END IF;

    IF v_status <> 'CONFIRMED' THEN
        ROLLBACK;
        SET p_status_code = 400;
        SET p_status_message = CONCAT('INVALID_STATUS: Cannot cancel a booking with status ', v_status);
        LEAVE proc_label;
    END IF;

    -- Lock and restore slot inventory
    SELECT id INTO v_inventory_id
    FROM slot_inventory
    WHERE temple_id = v_temple_id
      AND darshan_type_id = v_darshan_type_id
      AND slot_id = v_slot_id
      AND reservation_date = v_res_date
    FOR UPDATE;

    IF v_inventory_id IS NOT NULL THEN
        UPDATE slot_inventory
        SET reserved_count = GREATEST(0, reserved_count - v_devotees),
            version = version + 1
        WHERE id = v_inventory_id;
    END IF;

    -- Update booking status
    UPDATE bookings
    SET booking_status = 'CANCELLED'
    WHERE id = p_booking_id;

    -- Insert cancellation audit
    INSERT INTO cancellations (booking_id, cancelled_by, reason, refund_amount)
    VALUES (p_booking_id, p_user_id, p_reason, v_amount);

    -- Update payment status to REFUNDED
    UPDATE payments
    SET payment_status = 'REFUNDED'
    WHERE booking_id = p_booking_id;

    COMMIT;

    SET p_status_code = 200;
    SET p_status_message = 'SUCCESS: Booking successfully cancelled and capacity restored.';
END$$

-- 5. Stored Procedure with CURSOR: Daily Temple Devotee Manifest
DROP PROCEDURE IF EXISTS sp_generate_daily_manifest$$
CREATE PROCEDURE sp_generate_daily_manifest(
    IN p_temple_id BIGINT,
    IN p_date DATE
)
BEGIN
    -- Explicit Cursor Variables
    DECLARE v_done INT DEFAULT FALSE;
    DECLARE v_ref VARCHAR(30);
    DECLARE v_devotee_count INT;
    DECLARE v_slot_name VARCHAR(80);
    DECLARE v_darshan_name VARCHAR(120);
    DECLARE v_amount DECIMAL(10,2);
    
    -- Summary counters
    DECLARE v_total_bookings INT DEFAULT 0;
    DECLARE v_total_devotees INT DEFAULT 0;
    DECLARE v_total_revenue DECIMAL(10,2) DEFAULT 0.00;

    -- Declare Cursor for iterating rows
    DECLARE cur_manifest CURSOR FOR
        SELECT b.booking_reference, b.total_devotees, ts.slot_name, dt.name, b.total_amount
        FROM bookings b
        JOIN time_slots ts ON b.slot_id = ts.id
        JOIN darshan_types dt ON b.darshan_type_id = dt.id
        WHERE b.temple_id = p_temple_id 
          AND b.reservation_date = p_date 
          AND b.booking_status = 'CONFIRMED'
        ORDER BY ts.start_time ASC;

    -- Not found handler for cursor loop termination
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- Temporary table to hold computed manifest
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_daily_manifest (
        booking_ref VARCHAR(30),
        slot_name VARCHAR(80),
        darshan_name VARCHAR(120),
        devotee_count INT,
        amount DECIMAL(10,2)
    );
    DELETE FROM temp_daily_manifest;

    OPEN cur_manifest;

    manifest_loop: LOOP
        FETCH cur_manifest INTO v_ref, v_devotee_count, v_slot_name, v_darshan_name, v_amount;
        IF v_done THEN
            LEAVE manifest_loop;
        END IF;

        INSERT INTO temp_daily_manifest VALUES (v_ref, v_slot_name, v_darshan_name, v_devotee_count, v_amount);
        SET v_total_bookings = v_total_bookings + 1;
        SET v_total_devotees = v_total_devotees + v_devotee_count;
        SET v_total_revenue = v_total_revenue + v_amount;
    END LOOP manifest_loop;

    CLOSE cur_manifest;

    -- Return manifest result set
    SELECT * FROM temp_daily_manifest;
    
    -- Clean up temporary table
    DROP TEMPORARY TABLE IF EXISTS temp_daily_manifest;
END$$

DELIMITER ;
