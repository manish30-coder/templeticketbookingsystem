package com.divyayatra.model;

public class BookingDevotee {
    private Long id;
    private Long bookingId;
    private String fullName;
    private int age;
    private String gender; // MALE, FEMALE, OTHER
    private String idProofType;
    private String idProofNumber;
    private String tokenNumber;

    public BookingDevotee() {}

    public BookingDevotee(Long id, Long bookingId, String fullName, int age, String gender,
                          String idProofType, String idProofNumber, String tokenNumber) {
        this.id = id;
        this.bookingId = bookingId;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.idProofType = idProofType;
        this.idProofNumber = idProofNumber;
        this.tokenNumber = tokenNumber;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIdProofType() {
        return idProofType;
    }

    public void setIdProofType(String idProofType) {
        this.idProofType = idProofType;
    }

    public String getIdProofNumber() {
        return idProofNumber;
    }

    public void setIdProofNumber(String idProofNumber) {
        this.idProofNumber = idProofNumber;
    }

    public String getTokenNumber() {
        return tokenNumber;
    }

    public void setTokenNumber(String tokenNumber) {
        this.tokenNumber = tokenNumber;
    }
}
