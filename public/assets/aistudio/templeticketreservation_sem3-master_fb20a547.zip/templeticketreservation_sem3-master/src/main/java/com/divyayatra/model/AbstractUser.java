package com.divyayatra.model;

import java.time.LocalDateTime;

/**
 * AbstractUser represents the common base abstraction for all system actors.
 * Demonstrates Java OOP Syllabus Unit II:
 * - Abstract classes
 * - Member access (protected/private)
 * - Parameterized constructors and constructor chaining
 * - Abstract methods requiring polymorphic subclass implementations
 */
public abstract class AbstractUser {
    protected Long id;
    protected String fullName;
    protected String email;
    protected String phone;
    protected String passwordHash;
    protected UserRole role;
    protected boolean active;
    protected LocalDateTime createdAt;

    // Default Constructor
    public AbstractUser() {
        this.active = true;
        this.createdAt = LocalDateTime.now();
    }

    // Parameterized Constructor demonstrating constructor chaining
    public AbstractUser(Long id, String fullName, String email, String phone, String passwordHash, UserRole role) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.passwordHash = passwordHash;
        this.role = role;
        this.active = true;
        this.createdAt = LocalDateTime.now();
    }

    // Abstract method: Each subclass must define its dedicated dashboard route
    public abstract String getDashboardRoute();

    // Concrete method common to all users
    public boolean canPerformAdministrativeTasks() {
        return this.role == UserRole.ADMIN;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "AbstractUser{" +
                "id=" + id +
                ", fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", role=" + role +
                '}';
    }
}
