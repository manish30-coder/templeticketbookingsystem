package com.divyayatra.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Cancellation {
    private Long id;
    private Long bookingId;
    private Long cancelledBy;
    private String reason;
    private BigDecimal refundAmount;
    private LocalDateTime cancelledAt;

    public Cancellation() {
        this.refundAmount = BigDecimal.ZERO;
        this.cancelledAt = LocalDateTime.now();
    }

    public Cancellation(Long id, Long bookingId, Long cancelledBy, String reason, BigDecimal refundAmount) {
        this.id = id;
        this.bookingId = bookingId;
        this.cancelledBy = cancelledBy;
        this.reason = reason;
        this.refundAmount = refundAmount;
        this.cancelledAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Long getCancelledBy() {
        return cancelledBy;
    }

    public void setCancelledBy(Long cancelledBy) {
        this.cancelledBy = cancelledBy;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    public LocalDateTime getCancelledAt() {
        return cancelledAt;
    }

    public void setCancelledAt(LocalDateTime cancelledAt) {
        this.cancelledAt = cancelledAt;
    }
}
