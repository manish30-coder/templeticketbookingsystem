package com.divyayatra.service.impl;

import com.divyayatra.dto.BookingRequest;
import com.divyayatra.dto.BookingResponse;
import com.divyayatra.dto.CancelBookingRequest;
import com.divyayatra.exception.DivyaYatraException;
import com.divyayatra.exception.InvalidBookingStatusException;
import com.divyayatra.exception.InventoryNotFoundException;
import com.divyayatra.exception.SlotCapacityExceededException;
import com.divyayatra.model.Booking;
import com.divyayatra.repository.BookingJdbcRepository;
import com.divyayatra.repository.SlotInventoryJdbcRepository;
import com.divyayatra.repository.TempleJdbcRepository;
import com.divyayatra.service.CancellationPolicy;
import com.divyayatra.service.ReservationOperation;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * SmartReservationServiceImpl is the core engine for atomic, ACID ticket booking.
 * Demonstrates:
 * - Unit II & III: Implementation of multiple interfaces (ReservationOperation, CancellationPolicy)
 * - Custom Exception handling (throw, throws)
 * - ACID transaction demarcation with REPEATABLE_READ isolation
 */
@Service
public class SmartReservationServiceImpl implements ReservationOperation, CancellationPolicy {

    private final BookingJdbcRepository bookingRepository;
    private final SlotInventoryJdbcRepository slotInventoryRepository;
    private final TempleJdbcRepository templeRepository;

    public SmartReservationServiceImpl(BookingJdbcRepository bookingRepository,
                                       SlotInventoryJdbcRepository slotInventoryRepository,
                                       TempleJdbcRepository templeRepository) {
        this.bookingRepository = bookingRepository;
        this.slotInventoryRepository = slotInventoryRepository;
        this.templeRepository = templeRepository;
    }

    @Override
    public void validateEligibility(BookingRequest request) {
        if (request == null) {
            throw new DivyaYatraException("Booking request cannot be null", 400);
        }
        if (request.getDevotees() == null || request.getDevotees().isEmpty()) {
            throw new DivyaYatraException("At least one devotee must be registered", 400);
        }
        if (request.getDevotees().size() > 6) {
            throw new DivyaYatraException("Maximum 6 devotees permitted per reservation", 400);
        }
        if (request.getReservationDate().isBefore(LocalDate.now())) {
            throw new DivyaYatraException("Reservation date cannot be in the past", 400);
        }
    }

    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public BookingResponse processReservation(BookingRequest request) {
        validateEligibility(request);

        int devoteeCount = request.getDevotees().size();

        // Step 1: Call ACID Stored Procedure sp_reserve_tickets with Pessimistic Row Lock
        Map<String, Object> procResult = bookingRepository.executeReserveTicketsProcedure(
                request.getUserId(),
                request.getTempleId(),
                request.getDarshanTypeId(),
                request.getSlotId(),
                request.getReservationDate(),
                devoteeCount,
                request.getPaymentMethod()
        );

        Integer statusCode = (Integer) procResult.get("p_status_code");
        String statusMessage = (String) procResult.get("p_status_message");
        Long bookingId = (Long) procResult.get("p_booking_id");
        String bookingRef = (String) procResult.get("p_booking_reference");

        if (statusCode == null || statusCode != 200) {
            if (statusCode != null && statusCode == 409) {
                throw new SlotCapacityExceededException(statusMessage != null ? statusMessage : "Slot capacity exceeded.");
            } else if (statusCode != null && statusCode == 404) {
                throw new InventoryNotFoundException(statusMessage != null ? statusMessage : "Slot inventory not found.");
            } else {
                throw new DivyaYatraException(statusMessage != null ? statusMessage : "Reservation failed.",
                        statusCode != null ? statusCode : 500);
            }
        }

        // Step 2: Save individual devotees (separate rows, never comma-separated!)
        List<String> tokens = bookingRepository.saveBookingDevotees(bookingId, bookingRef, request.getDevotees());

        // Step 3: Retrieve booking details from view
        Map<String, Object> summary = bookingRepository.findDetailedBookingByReference(bookingRef)
                .orElseThrow(() -> new DivyaYatraException("Failed to load booking confirmation details", 500));

        BookingResponse response = new BookingResponse();
        response.setBookingId(bookingId);
        response.setBookingReference(bookingRef);
        response.setTempleName((String) summary.get("temple_name"));
        response.setDarshanName((String) summary.get("darshan_name"));
        response.setSlotName((String) summary.get("slot_name"));
        java.sql.Date d = (java.sql.Date) summary.get("reservation_date");
        if (d != null) response.setReservationDate(d.toLocalDate());
        response.setTotalDevotees(devoteeCount);
        response.setTotalAmount((BigDecimal) summary.get("total_amount"));
        response.setBookingStatus((String) summary.get("booking_status"));
        response.setTransactionReference((String) summary.get("transaction_reference"));
        response.setDevoteeTokens(tokens);
        response.setMessage("Harivara Prasadam! Your demonstration temple reservation is confirmed.");

        return response;
    }

    @Override
    public boolean isEligibleForCancellation(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new DivyaYatraException("Booking not found: " + bookingId, 404));
        return booking.isEligibleForCancellation();
    }

    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public boolean processCancellation(CancelBookingRequest request) {
        if (!isEligibleForCancellation(request.getBookingId())) {
            throw new InvalidBookingStatusException("This reservation is not eligible for cancellation.");
        }

        Map<String, Object> result = bookingRepository.executeCancelBookingProcedure(
                request.getBookingId(),
                request.getUserId(),
                request.getReason()
        );

        Integer statusCode = (Integer) result.get("p_status_code");
        String message = (String) result.get("p_status_message");

        if (statusCode == null || statusCode != 200) {
            throw new DivyaYatraException(message != null ? message : "Cancellation failed",
                    statusCode != null ? statusCode : 500);
        }

        return true;
    }
}
