package com.divyayatra.exception;

/**
 * Base custom runtime exception for Divya Yatra Platform.
 * Demonstrates Unit III: Custom Exception Handling in Java.
 */
public class DivyaYatraException extends RuntimeException {
    private final int statusCode;

    public DivyaYatraException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }

    public DivyaYatraException(String message, int statusCode, Throwable cause) {
        super(message, cause);
        this.statusCode = statusCode;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
