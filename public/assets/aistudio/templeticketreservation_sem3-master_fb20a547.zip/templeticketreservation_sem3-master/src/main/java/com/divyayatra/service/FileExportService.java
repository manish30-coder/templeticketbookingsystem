package com.divyayatra.service;

import com.divyayatra.exception.DivyaYatraException;
import com.divyayatra.model.BookingDevotee;
import com.divyayatra.repository.BookingJdbcRepository;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * FileExportService demonstrates Java OOP Unit IV Syllabus:
 * - Byte Streams (ByteArrayOutputStream, FileOutputStream)
 * - Character Streams (BufferedWriter, FileWriter, OutputStreamWriter)
 * - File I/O operations for generating Pilgrim E-Tickets and CSV Manifests
 */
@Service
public class FileExportService {

    private final BookingJdbcRepository bookingRepository;

    public FileExportService(BookingJdbcRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    /**
     * Generates an official Pilgrim Demonstration E-Pass using Character Streams (BufferedWriter).
     */
    public byte[] generateTicketPassFile(String bookingReference) {
        Map<String, Object> booking = bookingRepository.findDetailedBookingByReference(bookingReference)
                .orElseThrow(() -> new DivyaYatraException("Booking not found: " + bookingReference, 404));

        Long bookingId = (Long) booking.get("booking_id");
        List<BookingDevotee> devotees = bookingRepository.findDevoteesForBooking(bookingId);

        // Byte and Character Stream pipeline
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(byteOut, StandardCharsets.UTF_8))) {
            writer.write("====================================================================\n");
            writer.write("                     DIVYA YATRA PILGRIMAGE PASS                    \n");
            writer.write("            Unified Temple Ticket Reservation Platform (Demo)       \n");
            writer.write("====================================================================\n\n");

            writer.write("BOOKING REFERENCE  : " + booking.get("booking_reference") + "\n");
            writer.write("STATUS             : " + booking.get("booking_status") + "\n");
            writer.write("TEMPLE             : " + booking.get("temple_name") + " (" + booking.get("temple_city") + ", " + booking.get("temple_state") + ")\n");
            writer.write("DARSHAN CATEGORY   : " + booking.get("darshan_name") + "\n");
            writer.write("RESERVATION DATE   : " + booking.get("reservation_date") + "\n");
            writer.write("TIME SLOT          : " + booking.get("slot_name") + " [" + booking.get("start_time") + " - " + booking.get("end_time") + "]\n");
            writer.write("TOTAL DEVOTEES     : " + booking.get("total_devotees") + "\n");
            writer.write("TOTAL FEE PAID     : ₹" + booking.get("total_amount") + "\n");
            writer.write("TRANSACTION ID     : " + booking.get("transaction_reference") + " (" + booking.get("payment_method") + ")\n\n");

            writer.write("--------------------------------------------------------------------\n");
            writer.write("                      DEVOTEE PASSENGERS DETAILS                    \n");
            writer.write("--------------------------------------------------------------------\n");
            writer.write(String.format("%-6s | %-24s | %-5s | %-8s | %-16s | %-12s\n",
                    "SL NO", "DEVOTEE NAME", "AGE", "GENDER", "ID PROOF", "TOKEN NO"));
            writer.write("--------------------------------------------------------------------\n");

            int idx = 1;
            for (BookingDevotee d : devotees) {
                writer.write(String.format("%-6d | %-24s | %-5d | %-8s | %-16s | %-12s\n",
                        idx++,
                        d.getFullName(),
                        d.getAge(),
                        d.getGender(),
                        d.getIdProofType() + ": " + d.getIdProofNumber(),
                        d.getTokenNumber()));
            }

            writer.write("====================================================================\n");
            writer.write("IMPORTANT ADVISORY:\n");
            writer.write("1. Devotees must carry the original photo identity proof declared above.\n");
            writer.write("2. Report at the verification checkpoint 30 minutes before the scheduled slot.\n");
            writer.write("3. Traditional temple dress code is strictly enforced.\n");
            writer.write("4. This pass is an academic semester demonstration artifact.\n");
            writer.write("====================================================================\n");

            writer.flush();
        } catch (IOException e) {
            throw new DivyaYatraException("Error generating pilgrim pass file stream", 500, e);
        }

        return byteOut.toByteArray();
    }

    /**
     * Generates a CSV daily manifest report using Character Streams.
     */
    public byte[] generateDailyManifestCsv(Long templeId, java.time.LocalDate date) {
        List<Map<String, Object>> manifest = bookingRepository.executeDailyManifestCursor(templeId, date);

        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(byteOut, StandardCharsets.UTF_8))) {
            writer.write("BookingReference,SlotName,DarshanCategory,DevoteeCount,AmountPaid\n");

            for (Map<String, Object> row : manifest) {
                writer.write(String.format("%s,\"%s\",\"%s\",%s,%s\n",
                        row.get("booking_ref"),
                        row.get("slot_name"),
                        row.get("darshan_name"),
                        row.get("devotee_count"),
                        row.get("amount")));
            }
            writer.flush();
        } catch (IOException e) {
            throw new DivyaYatraException("Error writing CSV manifest stream", 500, e);
        }

        return byteOut.toByteArray();
    }
}
