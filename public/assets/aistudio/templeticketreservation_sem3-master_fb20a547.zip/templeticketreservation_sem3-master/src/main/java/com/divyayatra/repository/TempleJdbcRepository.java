package com.divyayatra.repository;

import com.divyayatra.model.DarshanType;
import com.divyayatra.model.Temple;
import com.divyayatra.model.TimeSlot;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Time;
import java.util.*;

@Repository
public class TempleJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public TempleJdbcRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Temple> templeRowMapper = (rs, rowNum) -> {
        Temple temple = new Temple();
        temple.setId(rs.getLong("id"));
        temple.setTempleCode(rs.getString("temple_code"));
        temple.setName(rs.getString("name"));
        temple.setState(rs.getString("state"));
        temple.setCity(rs.getString("city"));
        temple.setDeity(rs.getString("deity"));
        Time openTime = rs.getTime("opening_time");
        if (openTime != null) temple.setOpeningTime(openTime.toLocalTime());
        Time closeTime = rs.getTime("closing_time");
        if (closeTime != null) temple.setClosingTime(closeTime.toLocalTime());
        temple.setContactPhone(rs.getString("contact_phone"));
        temple.setContactEmail(rs.getString("contact_email"));
        temple.setImageUrl(rs.getString("image_url"));
        temple.setActive(rs.getBoolean("is_active"));
        return temple;
    };

    public List<Temple> findAll() {
        String sql = "SELECT * FROM temples WHERE is_active = TRUE ORDER BY name ASC";
        return jdbcTemplate.query(sql, templeRowMapper);
    }

    public List<Temple> findAllAdmin() {
        String sql = "SELECT * FROM temples ORDER BY id DESC";
        return jdbcTemplate.query(sql, templeRowMapper);
    }

    public Optional<Temple> findById(Long id) {
        String sql = "SELECT * FROM temples WHERE id = ?";
        List<Temple> results = jdbcTemplate.query(sql, templeRowMapper, id);
        return results.stream().findFirst();
    }

    public Optional<Temple> findByTempleCode(String code) {
        String sql = "SELECT * FROM temples WHERE temple_code = ?";
        List<Temple> results = jdbcTemplate.query(sql, templeRowMapper, code);
        return results.stream().findFirst();
    }

    public List<Temple> findByState(String state) {
        String sql = "SELECT * FROM temples WHERE LOWER(state) = LOWER(?) AND is_active = TRUE ORDER BY name ASC";
        return jdbcTemplate.query(sql, templeRowMapper, state);
    }

    public List<String> findAllDistinctStates() {
        String sql = "SELECT DISTINCT state FROM temples WHERE is_active = TRUE ORDER BY state ASC";
        return jdbcTemplate.queryForList(sql, String.class);
    }

    public Long save(Temple temple) {
        String sql = "INSERT INTO temples (temple_code, name, state, city, deity, opening_time, closing_time, contact_phone, contact_email, image_url, is_active) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, temple.getTempleCode());
            ps.setString(2, temple.getName());
            ps.setString(3, temple.getState());
            ps.setString(4, temple.getCity());
            ps.setString(5, temple.getDeity());
            ps.setTime(6, Time.valueOf(temple.getOpeningTime() != null ? temple.getOpeningTime() : java.time.LocalTime.of(6, 0)));
            ps.setTime(7, Time.valueOf(temple.getClosingTime() != null ? temple.getClosingTime() : java.time.LocalTime.of(21, 0)));
            ps.setString(8, temple.getContactPhone());
            ps.setString(9, temple.getContactEmail());
            ps.setString(10, temple.getImageUrl());
            ps.setBoolean(11, temple.isActive());
            return ps;
        }, keyHolder);

        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public boolean update(Temple temple) {
        String sql = "UPDATE temples SET name = ?, state = ?, city = ?, deity = ?, opening_time = ?, closing_time = ?, " +
                "contact_phone = ?, contact_email = ?, image_url = ?, is_active = ? WHERE id = ?";
        int rows = jdbcTemplate.update(sql,
                temple.getName(),
                temple.getState(),
                temple.getCity(),
                temple.getDeity(),
                Time.valueOf(temple.getOpeningTime()),
                Time.valueOf(temple.getClosingTime()),
                temple.getContactPhone(),
                temple.getContactEmail(),
                temple.getImageUrl(),
                temple.isActive(),
                temple.getId());
        return rows > 0;
    }

    public boolean delete(Long id) {
        String sql = "UPDATE temples SET is_active = FALSE WHERE id = ?";
        return jdbcTemplate.update(sql, id) > 0;
    }

    public List<Map<String, Object>> getDarshanTypesForTemple(Long templeId) {
        String sql = "SELECT dt.id, dt.code, dt.name, dt.description, td.base_price, td.max_devotees_per_booking, td.rules " +
                "FROM darshan_types dt " +
                "JOIN temple_darshan td ON dt.id = td.darshan_type_id " +
                "WHERE td.temple_id = ? AND dt.is_active = TRUE AND td.is_active = TRUE " +
                "ORDER BY td.base_price ASC";
        return jdbcTemplate.queryForList(sql, templeId);
    }

    public List<TimeSlot> getTimeSlotsForTemple(Long templeId) {
        String sql = "SELECT * FROM time_slots WHERE temple_id = ? AND is_active = TRUE ORDER BY start_time ASC";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            TimeSlot slot = new TimeSlot();
            slot.setId(rs.getLong("id"));
            slot.setTempleId(rs.getLong("temple_id"));
            slot.setSlotName(rs.getString("slot_name"));
            Time sTime = rs.getTime("start_time");
            if (sTime != null) slot.setStartTime(sTime.toLocalTime());
            Time eTime = rs.getTime("end_time");
            if (eTime != null) slot.setEndTime(eTime.toLocalTime());
            slot.setActive(rs.getBoolean("is_active"));
            return slot;
        }, templeId);
    }

    public long countActiveTemples() {
        return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM temples WHERE is_active = TRUE", Long.class);
    }
}
