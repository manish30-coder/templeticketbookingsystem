package com.divyayatra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DivyaYatraApplication {

    public static void main(String[] args) {
        SpringApplication.run(DivyaYatraApplication.class, args);
    }
}
