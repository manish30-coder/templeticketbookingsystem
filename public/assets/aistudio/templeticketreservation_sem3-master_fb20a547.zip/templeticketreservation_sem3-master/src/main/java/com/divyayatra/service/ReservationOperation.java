package com.divyayatra.service;

import com.divyayatra.dto.BookingRequest;
import com.divyayatra.dto.BookingResponse;

/**
 * ReservationOperation interface.
 * Demonstrates Unit III: Java Interfaces and Implementations.
 */
public interface ReservationOperation {

    /**
     * Validates eligibility of devotee count and inputs
     */
    void validateEligibility(BookingRequest request);

    /**
     * Executes atomic reservation transaction with row-level pessimistic locking
     */
    BookingResponse processReservation(BookingRequest request);
}
