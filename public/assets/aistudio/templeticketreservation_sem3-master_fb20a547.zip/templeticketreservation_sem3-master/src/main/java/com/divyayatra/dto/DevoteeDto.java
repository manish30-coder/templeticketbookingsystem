package com.divyayatra.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class DevoteeDto {
    @NotBlank(message = "Devotee full name is required")
    private String fullName;

    @NotNull(message = "Devotee age is required")
    @Min(value = 1, message = "Age must be at least 1")
    private Integer age;

    @NotBlank(message = "Gender is required (MALE/FEMALE/OTHER)")
    private String gender;

    @NotBlank(message = "ID Proof Type is required (e.g. AADHAAR, PASSPORT, VOTER_ID)")
    private String idProofType;

    @NotBlank(message = "ID Proof Number is required")
    private String idProofNumber;

    public DevoteeDto() {}

    public DevoteeDto(String fullName, Integer age, String gender, String idProofType, String idProofNumber) {
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.idProofType = idProofType;
        this.idProofNumber = idProofNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIdProofType() {
        return idProofType;
    }

    public void setIdProofType(String idProofType) {
        this.idProofType = idProofType;
    }

    public String getIdProofNumber() {
        return idProofNumber;
    }

    public void setIdProofNumber(String idProofNumber) {
        this.idProofNumber = idProofNumber;
    }
}
