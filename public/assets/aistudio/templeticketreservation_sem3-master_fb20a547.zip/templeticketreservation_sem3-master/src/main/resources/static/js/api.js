/**
 * DIVYA YATRA: Central API & Session Client
 * Connects frontend views directly with Spring Boot REST endpoints.
 */

const API_BASE = '/api';

const API = {
    // -------------------------------------------------------------
    // Authentication & Session
    // -------------------------------------------------------------
    async login(email, password) {
        const response = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message || 'Login failed');
        }
        this.setAuthUser(data);
        return data;
    },

    async register(payload) {
        const response = await fetch(`${API_BASE}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message || 'Registration failed');
        }
        this.setAuthUser(data);
        return data;
    },

    setAuthUser(user) {
        localStorage.setItem('divya_user', JSON.stringify(user));
    },

    getAuthUser() {
        const data = localStorage.getItem('divya_user');
        return data ? JSON.parse(data) : null;
    },

    logout() {
        localStorage.removeItem('divya_user');
        window.location.href = '/pages/login.html';
    },

    requireAuth(allowedRole = null) {
        const user = this.getAuthUser();
        if (!user) {
            window.location.href = '/pages/login.html';
            return null;
        }
        if (allowedRole && user.role !== allowedRole) {
            alert(`Access restricted. You need ${allowedRole} privileges.`);
            window.location.href = user.dashboardRoute || '/';
            return null;
        }
        return user;
    },

    // -------------------------------------------------------------
    // Temples & Live Availability
    // -------------------------------------------------------------
    async getTemples(state = null) {
        let url = `${API_BASE}/temples`;
        if (state && state !== 'ALL') {
            url += `?state=${encodeURIComponent(state)}`;
        }
        const res = await fetch(url);
        return await res.json();
    },

    async getStates() {
        const res = await fetch(`${API_BASE}/temples/states`);
        return await res.json();
    },

    async getTempleDetails(id) {
        const res = await fetch(`${API_BASE}/temples/${id}`);
        if (!res.ok) throw new Error('Temple not found');
        return await res.json();
    },

    async getLiveAvailability(templeId, dateStr) {
        const res = await fetch(`${API_BASE}/temples/${templeId}/availability?date=${dateStr}`);
        return await res.json();
    },

    // -------------------------------------------------------------
    // Reservations & Devotee Desk
    // -------------------------------------------------------------
    async reserveTickets(payload) {
        const response = await fetch(`${API_BASE}/bookings/reserve`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message || 'Reservation failed');
        }
        return data;
    },

    async cancelBooking(bookingId, userId, reason) {
        const response = await fetch(`${API_BASE}/bookings/cancel`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bookingId, userId, reason })
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message || 'Cancellation failed');
        }
        return data;
    },

    async getBookingByReference(reference) {
        const res = await fetch(`${API_BASE}/bookings/${reference}`);
        if (!res.ok) throw new Error('Booking reference not found');
        return await res.json();
    },

    async getUserBookings(userId) {
        const res = await fetch(`${API_BASE}/bookings/user/${userId}`);
        return await res.json();
    },

    // -------------------------------------------------------------
    // Staff Desk Operations
    // -------------------------------------------------------------
    async staffLookup(reference) {
        const res = await fetch(`${API_BASE}/staff/lookup/${reference}`);
        if (!res.ok) throw new Error('Ticket reference not found');
        return await res.json();
    },

    async staffDailyManifest(templeId, dateStr) {
        const res = await fetch(`${API_BASE}/staff/temple-manifest?templeId=${templeId}&date=${dateStr}`);
        return await res.json();
    },

    async staffDailyBookings(templeId, dateStr) {
        const res = await fetch(`${API_BASE}/staff/daily-bookings?templeId=${templeId}&date=${dateStr}`);
        return await res.json();
    },

    // -------------------------------------------------------------
    // Admin Operations
    // -------------------------------------------------------------
    async getAdminMetrics() {
        const res = await fetch(`${API_BASE}/admin/metrics`);
        return await res.json();
    },

    async getAdminRevenueStats() {
        const res = await fetch(`${API_BASE}/admin/revenue-stats`);
        return await res.json();
    },

    async getAdminTemples() {
        const res = await fetch(`${API_BASE}/admin/temples`);
        return await res.json();
    },

    async addTemple(payload) {
        const res = await fetch(`${API_BASE}/admin/temples`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        return await res.json();
    },

    async updateTemple(payload) {
        const res = await fetch(`${API_BASE}/admin/temples`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        return await res.json();
    },

    async deleteTemple(id) {
        const res = await fetch(`${API_BASE}/admin/temples/${id}`, { method: 'DELETE' });
        return await res.json();
    },

    async updateSlotCapacity(inventoryId, newCapacity) {
        const res = await fetch(`${API_BASE}/admin/slots/capacity?inventoryId=${inventoryId}&newCapacity=${newCapacity}`, {
            method: 'PUT'
        });
        return await res.json();
    },

    async getAllUsers() {
        const res = await fetch(`${API_BASE}/admin/users`);
        return await res.json();
    },

    async getStreamAnalytics(templeId, dateStr) {
        let url = `${API_BASE}/reports/stream-analytics?templeId=${templeId}`;
        if (dateStr) url += `&date=${dateStr}`;
        const res = await fetch(url);
        return await res.json();
    }
};

// Global Header Navigation State Updater
function updateNavAuth() {
    const user = API.getAuthUser();
    const navActionContainer = document.getElementById('nav-user-actions');
    if (!navActionContainer) return;

    if (user) {
        navActionContainer.innerHTML = `
            <a href="${user.dashboardRoute}" class="btn-outline-gold" style="padding: 0.5rem 1rem; font-size: 0.8rem;">
                <i data-lucide="layout-dashboard"></i> ${user.fullName.split(' ')[0]} (${user.role})
            </a>
            <button onclick="API.logout()" class="btn-gold" style="padding: 0.5rem 0.9rem; font-size: 0.8rem;">
                Logout
            </button>
        `;
    } else {
        navActionContainer.innerHTML = `
            <a href="/pages/login.html" class="btn-outline-gold" style="padding: 0.5rem 1rem; font-size: 0.8rem;">Login</a>
            <a href="/pages/booking.html" class="btn-gold" style="padding: 0.5rem 1rem; font-size: 0.8rem;">Book Darshan</a>
        `;
    }
    if (window.lucide) lucide.createIcons();
}

document.addEventListener('DOMContentLoaded', updateNavAuth);
