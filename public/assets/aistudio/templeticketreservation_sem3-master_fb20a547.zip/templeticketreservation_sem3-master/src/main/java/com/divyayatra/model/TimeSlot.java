package com.divyayatra.model;

import java.time.LocalTime;

public class TimeSlot {
    private Long id;
    private Long templeId;
    private String slotName;
    private LocalTime startTime;
    private LocalTime endTime;
    private boolean active;

    public TimeSlot() {
        this.active = true;
    }

    public TimeSlot(Long id, Long templeId, String slotName, LocalTime startTime, LocalTime endTime, boolean active) {
        this.id = id;
        this.templeId = templeId;
        this.slotName = slotName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.active = active;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTempleId() {
        return templeId;
    }

    public void setTempleId(Long templeId) {
        this.templeId = templeId;
    }

    public String getSlotName() {
        return slotName;
    }

    public void setSlotName(String slotName) {
        this.slotName = slotName;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
