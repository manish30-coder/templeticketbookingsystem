package com.divyayatra.service;

import com.divyayatra.dto.AuthResponse;
import com.divyayatra.dto.LoginRequest;
import com.divyayatra.dto.RegisterRequest;
import com.divyayatra.exception.AuthenticationException;
import com.divyayatra.exception.DivyaYatraException;
import com.divyayatra.model.*;
import com.divyayatra.repository.UserJdbcRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class AuthService {

    private final UserJdbcRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public AuthService(UserJdbcRepository userRepository) {
        this.userRepository = userRepository;
    }

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new DivyaYatraException("Email address is already registered: " + request.getEmail(), 400);
        }

        String hashedPassword = passwordEncoder.encode(request.getPassword());
        UserRole role = UserRole.DEVOTEE;
        if (request.getRole() != null) {
            try {
                role = UserRole.valueOf(request.getRole().toUpperCase());
            } catch (IllegalArgumentException e) {
                role = UserRole.DEVOTEE;
            }
        }

        AbstractUser newUser;
        if (role == UserRole.STAFF) {
            newUser = new Staff(null, request.getFullName(), request.getEmail(), request.getPhone(),
                    hashedPassword, 1L, "EMP-" + UUID.randomUUID().toString().substring(0, 6));
        } else if (role == UserRole.ADMIN) {
            newUser = new Administrator(null, request.getFullName(), request.getEmail(), request.getPhone(),
                    hashedPassword, "Central Administration");
        } else {
            newUser = new Devotee(null, request.getFullName(), request.getEmail(), request.getPhone(),
                    hashedPassword, request.getIdProofType() != null ? request.getIdProofType() : "AADHAAR",
                    request.getIdProofNumber() != null ? request.getIdProofNumber() : "N/A");
        }

        Long userId = userRepository.save(newUser);
        newUser.setId(userId);

        String demoToken = "DY_SESSION_" + UUID.randomUUID();
        return new AuthResponse(
                userId,
                newUser.getFullName(),
                newUser.getEmail(),
                newUser.getRole().name(),
                newUser.getDashboardRoute(),
                demoToken,
                "Devotee registration successful!"
        );
    }

    public AuthResponse login(LoginRequest request) {
        AbstractUser user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new AuthenticationException("Invalid email or password."));

        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            throw new AuthenticationException("Invalid email or password.");
        }

        String demoToken = "DY_SESSION_" + UUID.randomUUID();
        return new AuthResponse(
                user.getId(),
                user.getFullName(),
                user.getEmail(),
                user.getRole().name(),
                user.getDashboardRoute(),
                demoToken,
                "Authentication successful. Welcome, " + user.getFullName()
        );
    }

    public AbstractUser getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new DivyaYatraException("User not found: " + id, 404));
    }
}
