package com.divyayatra.service;

import com.divyayatra.repository.BookingJdbcRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * AnalyticsStreamService explicitly demonstrates Java OOP Unit V Syllabus:
 * - Stream API
 * - Filtering with Predicates
 * - Mapping with Function
 * - Reduction (reduce)
 * - Collecting (toList, groupingBy, summarizingDouble)
 * - Parallel Stream processing
 * - Iterator traversal
 * - Lambda expressions
 */
@Service
public class AnalyticsStreamService {

    private final BookingJdbcRepository bookingRepository;

    public AnalyticsStreamService(BookingJdbcRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    /**
     * Demonstrates Stream filtering, mapping, and reduction for gross revenue.
     */
    public BigDecimal calculateGrossConfirmedRevenue(Long templeId, java.time.LocalDate date) {
        List<Map<String, Object>> bookings = bookingRepository.findDetailedBookingsByTempleAndDate(templeId, date);

        Predicate<Map<String, Object>> isConfirmed = row -> "CONFIRMED".equalsIgnoreCase((String) row.get("booking_status"));
        Function<Map<String, Object>, BigDecimal> extractAmount = row -> (BigDecimal) row.get("total_amount");

        // Stream reduction using lambda
        return bookings.stream()
                .filter(isConfirmed)
                .map(extractAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Demonstrates Stream groupingBy (aggregating reservations per Darshan type).
     */
    public Map<String, Long> getBookingsCountByDarshanCategory(Long templeId, java.time.LocalDate date) {
        List<Map<String, Object>> bookings = bookingRepository.findDetailedBookingsByTempleAndDate(templeId, date);

        return bookings.stream()
                .collect(Collectors.groupingBy(
                        row -> (String) row.get("darshan_name"),
                        Collectors.counting()
                ));
    }

    /**
     * Demonstrates Parallel Streams for fast processing across large dataset.
     */
    public List<String> extractAllConfirmedReferencesParallel() {
        List<Map<String, Object>> stats = bookingRepository.getTempleRevenueStats();

        // Parallel Stream demonstration
        return stats.parallelStream()
                .map(row -> String.format("%s [Revenue: ₹%s]", row.get("temple_name"), row.get("gross_revenue")))
                .collect(Collectors.toList());
    }

    /**
     * Demonstrates Iterator collection traversal (Unit V syllabus requirement).
     */
    public List<Map<String, Object>> filterBookingsUsingIterator(List<Map<String, Object>> list, String targetStatus) {
        List<Map<String, Object>> matched = new ArrayList<>();
        Iterator<Map<String, Object>> iterator = list.iterator();

        while (iterator.hasNext()) {
            Map<String, Object> item = iterator.next();
            if (targetStatus.equalsIgnoreCase((String) item.get("booking_status"))) {
                matched.add(item);
            }
        }
        return matched;
    }
}
