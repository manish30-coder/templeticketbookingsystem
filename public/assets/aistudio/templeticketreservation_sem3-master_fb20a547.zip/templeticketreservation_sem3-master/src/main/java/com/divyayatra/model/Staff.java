package com.divyayatra.model;

/**
 * Staff domain model representing temple counter officers and marshals.
 */
public class Staff extends AbstractUser {
    private Long assignedTempleId;
    private String employeeCode;

    public Staff() {
        super();
        this.role = UserRole.STAFF;
    }

    public Staff(Long id, String fullName, String email, String phone, String passwordHash,
                 Long assignedTempleId, String employeeCode) {
        super(id, fullName, email, phone, passwordHash, UserRole.STAFF);
        this.assignedTempleId = assignedTempleId;
        this.employeeCode = employeeCode;
    }

    @Override
    public String getDashboardRoute() {
        return "/pages/staff_dashboard.html";
    }

    public Long getAssignedTempleId() {
        return assignedTempleId;
    }

    public void setAssignedTempleId(Long assignedTempleId) {
        this.assignedTempleId = assignedTempleId;
    }

    public String getEmployeeCode() {
        return employeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }
}
