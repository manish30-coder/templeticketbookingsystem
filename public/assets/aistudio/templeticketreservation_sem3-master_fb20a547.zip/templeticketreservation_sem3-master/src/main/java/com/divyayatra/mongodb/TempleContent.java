package com.divyayatra.mongodb;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;
import java.util.Map;

/**
 * TempleContent document model stored in MongoDB.
 * Preserves rich narrative histories, architectural styles, sanctum details,
 * ritual schedules, dress codes, and media galleries.
 * Demonstrates Unit V: Flexible Document Schema in NoSQL.
 */
@Document(collection = "temple_content")
public class TempleContent {

    @Id
    private String id;

    @Field("temple_code")
    private String templeCode;
    private String name;
    private String deity;
    private String state;
    private String city;
    private String history;
    private String architecture_style;
    private String sanctum_details;
    private List<Map<String, String>> rituals_schedule;
    private Map<String, String> dress_code;
    private Map<String, List<String>> dos_and_donts;
    private List<Map<String, String>> media_gallery;
    private Map<String, Double> coordinates;

    public TempleContent() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTempleCode() {
        return templeCode;
    }

    public void setTempleCode(String templeCode) {
        this.templeCode = templeCode;
    }

    // Retain snake_case accessors for backwards compatibility with JSON deserialization
    public String getTemple_code() {
        return templeCode;
    }

    public void setTemple_code(String temple_code) {
        this.templeCode = temple_code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeity() {
        return deity;
    }

    public void setDeity(String deity) {
        this.deity = deity;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getArchitecture_style() {
        return architecture_style;
    }

    public void setArchitecture_style(String architecture_style) {
        this.architecture_style = architecture_style;
    }

    public String getSanctum_details() {
        return sanctum_details;
    }

    public void setSanctum_details(String sanctum_details) {
        this.sanctum_details = sanctum_details;
    }

    public List<Map<String, String>> getRituals_schedule() {
        return rituals_schedule;
    }

    public void setRituals_schedule(List<Map<String, String>> rituals_schedule) {
        this.rituals_schedule = rituals_schedule;
    }

    public Map<String, String> getDress_code() {
        return dress_code;
    }

    public void setDress_code(Map<String, String> dress_code) {
        this.dress_code = dress_code;
    }

    public Map<String, List<String>> getDos_and_donts() {
        return dos_and_donts;
    }

    public void setDos_and_donts(Map<String, List<String>> dos_and_donts) {
        this.dos_and_donts = dos_and_donts;
    }

    public List<Map<String, String>> getMedia_gallery() {
        return media_gallery;
    }

    public void setMedia_gallery(List<Map<String, String>> media_gallery) {
        this.media_gallery = media_gallery;
    }

    public Map<String, Double> getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(Map<String, Double> coordinates) {
        this.coordinates = coordinates;
    }
}
