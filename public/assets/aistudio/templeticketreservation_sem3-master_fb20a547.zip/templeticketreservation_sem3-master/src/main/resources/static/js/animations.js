/**
 * DIVYA YATRA: GSAP & ScrollTrigger Heritage Animations
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check if GSAP is available
    if (typeof gsap === 'undefined') {
        console.warn('GSAP library not detected. Degrading to standard transitions.');
        const curtain = document.getElementById('cinematic-curtain');
        if (curtain) curtain.style.display = 'none';
        return;
    }

    if (typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);
    }

    // 1. Cinematic Opening Curtain Reveal
    const curtain = document.getElementById('cinematic-curtain');
    if (curtain) {
        const tl = gsap.timeline();
        tl.to('.curtain-content', {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: 'power2.out'
        })
        .to(curtain, {
            yPercent: -100,
            duration: 1.1,
            ease: 'power3.inOut',
            delay: 0.6,
            onComplete: () => {
                curtain.style.display = 'none';
            }
        })
        .from('.hero-content > *', {
            opacity: 0,
            y: 35,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power2.out'
        }, '-=0.4');
    }

    // 2. Hero Background Parallax Movement
    const heroBg = document.querySelector('.hero-background-image');
    if (heroBg && typeof ScrollTrigger !== 'undefined') {
        gsap.to(heroBg, {
            yPercent: 20,
            scale: 1.15,
            ease: 'none',
            scrollTrigger: {
                trigger: '.hero-section',
                start: 'top top',
                end: 'bottom top',
                scrub: true
            }
        });
    }

    // 3. Scroll-triggered Reveal for Narrative Section
    if (typeof ScrollTrigger !== 'undefined') {
        gsap.from('.narrative-image-wrapper', {
            opacity: 0,
            x: -50,
            duration: 1,
            ease: 'power2.out',
            scrollTrigger: {
                trigger: '.heritage-narrative-section',
                start: 'top 75%'
            }
        });

        gsap.from('.narrative-content > *', {
            opacity: 0,
            x: 50,
            duration: 0.8,
            stagger: 0.2,
            ease: 'power2.out',
            scrollTrigger: {
                trigger: '.heritage-narrative-section',
                start: 'top 75%'
            }
        });

        // 4. Staggered reveal for Temple Showcase Cards
        gsap.from('.temple-card', {
            opacity: 0,
            y: 40,
            duration: 0.7,
            stagger: 0.12,
            ease: 'power2.out',
            scrollTrigger: {
                trigger: '.temples-showcase-section',
                start: 'top 70%'
            }
        });

        // 5. Staggered reveal for 4-Step Reservation Process
        gsap.from('.step-card', {
            opacity: 0,
            y: 30,
            duration: 0.6,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
                trigger: '.steps-section',
                start: 'top 75%'
            }
        });

        // 6. Reveal for Festival Cards
        gsap.from('.festival-card', {
            opacity: 0,
            scale: 0.95,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
                trigger: '.festivals-section',
                start: 'top 75%'
            }
        });
    }
});
