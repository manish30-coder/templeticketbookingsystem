package com.divyayatra.model;

/**
 * Administrator domain model representing platform superintendents.
 */
public class Administrator extends AbstractUser {
    private String department;

    public Administrator() {
        super();
        this.role = UserRole.ADMIN;
    }

    public Administrator(Long id, String fullName, String email, String phone, String passwordHash, String department) {
        super(id, fullName, email, phone, passwordHash, UserRole.ADMIN);
        this.department = department;
    }

    @Override
    public String getDashboardRoute() {
        return "/pages/admin_dashboard.html";
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
