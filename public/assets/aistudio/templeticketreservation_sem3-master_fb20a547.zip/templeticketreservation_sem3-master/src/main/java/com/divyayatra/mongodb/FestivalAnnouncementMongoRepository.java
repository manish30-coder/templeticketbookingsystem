package com.divyayatra.mongodb;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FestivalAnnouncementMongoRepository extends MongoRepository<FestivalAnnouncement, String> {
    List<FestivalAnnouncement> findByTempleCode(String templeCode);
    List<FestivalAnnouncement> findByPriority(String priority);
}
