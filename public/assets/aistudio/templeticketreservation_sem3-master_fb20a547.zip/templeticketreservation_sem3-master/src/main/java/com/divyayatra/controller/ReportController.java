package com.divyayatra.controller;

import com.divyayatra.service.AnalyticsStreamService;
import com.divyayatra.service.FileExportService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    private final FileExportService fileExportService;
    private final AnalyticsStreamService analyticsStreamService;

    public ReportController(FileExportService fileExportService,
                            AnalyticsStreamService analyticsStreamService) {
        this.fileExportService = fileExportService;
        this.analyticsStreamService = analyticsStreamService;
    }

    /**
     * Downloads devotee ticket pass generated via Byte & Character streams.
     * Demonstrates Java OOP Unit IV: Byte and Character stream I/O.
     */
    @GetMapping("/ticket-download/{reference}")
    public ResponseEntity<byte[]> downloadTicketPass(@PathVariable String reference) {
        byte[] content = fileExportService.generateTicketPassFile(reference);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"Pass_" + reference + ".txt\"")
                .contentType(MediaType.TEXT_PLAIN)
                .body(content);
    }

    /**
     * Downloads daily manifest CSV.
     */
    @GetMapping("/manifest-csv")
    public ResponseEntity<byte[]> downloadManifestCsv(
            @RequestParam Long templeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        byte[] csv = fileExportService.generateDailyManifestCsv(templeId, date);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"Daily_Manifest_" + templeId + "_" + date + ".csv\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(csv);
    }

    /**
     * Returns Java Stream API calculations.
     * Demonstrates Java OOP Unit V: Stream filtering, reduction, mapping, and parallel streams.
     */
    @GetMapping("/stream-analytics")
    public ResponseEntity<Map<String, Object>> getStreamAnalytics(
            @RequestParam(defaultValue = "1") Long templeId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        LocalDate targetDate = (date != null) ? date : LocalDate.now();

        BigDecimal revenueReduction = analyticsStreamService.calculateGrossConfirmedRevenue(templeId, targetDate);
        Map<String, Long> categoryCount = analyticsStreamService.getBookingsCountByDarshanCategory(templeId, targetDate);
        List<String> parallelList = analyticsStreamService.extractAllConfirmedReferencesParallel();

        Map<String, Object> resp = new HashMap<>();
        resp.put("templeId", templeId);
        resp.put("targetDate", targetDate);
        resp.put("streamReductionGrossRevenue", revenueReduction);
        resp.put("streamGroupingByCategory", categoryCount);
        resp.put("parallelStreamTempleSummaries", parallelList);

        return ResponseEntity.ok(resp);
    }
}
