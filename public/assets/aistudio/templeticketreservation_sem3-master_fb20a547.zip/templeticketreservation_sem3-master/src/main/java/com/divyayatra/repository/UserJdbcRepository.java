package com.divyayatra.repository;

import com.divyayatra.model.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

/**
 * UserJdbcRepository provides transparent, explicit JDBC database interactions.
 * Demonstrates Unit V: JDBC PreparedStatement, ResultSet mapping, KeyHolder.
 */
@Repository
public class UserJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public UserJdbcRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<AbstractUser> userRowMapper = (rs, rowNum) -> {
        String roleStr = rs.getString("role");
        UserRole role = UserRole.valueOf(roleStr);
        Long id = rs.getLong("id");
        String fullName = rs.getString("full_name");
        String email = rs.getString("email");
        String phone = rs.getString("phone");
        String passwordHash = rs.getString("password_hash");
        Timestamp createdAt = rs.getTimestamp("created_at");

        AbstractUser user;
        switch (role) {
            case DEVOTEE:
                Devotee devotee = new Devotee(id, fullName, email, phone, passwordHash,
                        rs.getString("id_proof_type"), rs.getString("id_proof_number"));
                user = devotee;
                break;
            case STAFF:
                Staff staff = new Staff(id, fullName, email, phone, passwordHash,
                        1L, "EMP-" + id);
                user = staff;
                break;
            case ADMIN:
                Administrator admin = new Administrator(id, fullName, email, phone, passwordHash, "Central Pilgrimage Board");
                user = admin;
                break;
            default:
                throw new IllegalArgumentException("Unknown user role: " + roleStr);
        }
        user.setActive(rs.getBoolean("is_active"));
        if (createdAt != null) {
            user.setCreatedAt(createdAt.toLocalDateTime());
        }
        return user;
    };

    public Optional<AbstractUser> findByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ? AND is_active = TRUE";
        List<AbstractUser> results = jdbcTemplate.query(sql, userRowMapper, email);
        return results.stream().findFirst();
    }

    public Optional<AbstractUser> findById(Long id) {
        String sql = "SELECT * FROM users WHERE id = ?";
        List<AbstractUser> results = jdbcTemplate.query(sql, userRowMapper, id);
        return results.stream().findFirst();
    }

    public Long save(AbstractUser user) {
        String sql = "INSERT INTO users (full_name, email, phone, password_hash, role, id_proof_type, id_proof_number, is_active) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getPasswordHash());
            ps.setString(5, user.getRole().name());

            if (user instanceof Devotee) {
                Devotee d = (Devotee) user;
                ps.setString(6, d.getIdProofType());
                ps.setString(7, d.getIdProofNumber());
            } else {
                ps.setString(6, "OFFICIAL");
                ps.setString(7, "N/A");
            }
            ps.setBoolean(8, user.isActive());
            return ps;
        }, keyHolder);

        Number key = keyHolder.getKey();
        if (key != null) {
            user.setId(key.longValue());
            return key.longValue();
        }
        return null;
    }

    public List<AbstractUser> findAll() {
        String sql = "SELECT * FROM users ORDER BY id DESC";
        return jdbcTemplate.query(sql, userRowMapper);
    }

    public long countAll() {
        return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Long.class);
    }
}
