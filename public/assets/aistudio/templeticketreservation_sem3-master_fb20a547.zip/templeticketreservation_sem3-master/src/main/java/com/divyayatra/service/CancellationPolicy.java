package com.divyayatra.service;

import com.divyayatra.dto.CancelBookingRequest;

/**
 * CancellationPolicy interface.
 * Demonstrates Unit III: Java Interfaces.
 */
public interface CancellationPolicy {

    /**
     * Checks if a booking meets refund and cancellation criteria
     */
    boolean isEligibleForCancellation(Long bookingId);

    /**
     * Executes atomic cancellation and restores slot capacity
     */
    boolean processCancellation(CancelBookingRequest request);
}
