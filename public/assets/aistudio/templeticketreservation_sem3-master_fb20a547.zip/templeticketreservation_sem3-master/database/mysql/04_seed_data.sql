-- ===================================================================
-- DIVYA YATRA: Unified Temple Ticket Reservation Platform
-- File: 04_seed_data.sql
-- Description: Master Seed Data (Default 8 Temples, Darshan, Slots, RBAC)
-- Target RDBMS: MySQL 8.x / 9.x
-- ===================================================================

USE divyayatra_db;

-- 1. Initial Seed Users (Devotee, Staff, Administrator)
-- Passwords:
-- Admin:    AdminPassword@123
-- Staff:    StaffPassword@123
-- Devotee:  DevoteePassword@123
INSERT INTO users (id, full_name, email, phone, password_hash, role, id_proof_type, id_proof_number, is_active) VALUES
(1, 'Srikanth Ramanathan (Chief Administrator)', 'admin@divyayatra.org', '+91 9876543210', '$2a$10$UD3vdnYb4qSAD6GKgMmw.Or2Zy7dSFXRnNiaD8QbIMkVoEFUeQgcO', 'ADMIN', 'AADHAAR', '9988-7766-5544', TRUE),
(2, 'Anand Deshmukh (Temple Verification Officer)', 'staff@divyayatra.org', '+91 9845012345', '$2a$10$.ZP2AHQXHYp/YWz8/fVVOuUl1oSckVp.h4GpckKTQaXSqhzkSyHHa', 'STAFF', 'EMPLOYEE_ID', 'EMP-TTD-2041', TRUE),
(3, 'Gayatri Sundaram (Registered Devotee)', 'devotee@divyayatra.org', '+91 9789012345', '$2a$10$bESa44OJVLuaO66V2Ufq8uGJNoYvoGElRCrsJOARy8pu1o/3pz//C', 'DEVOTEE', 'AADHAAR', '1234-5678-9012', TRUE)
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name);

-- 2. Default 8 Sacred Temples
INSERT INTO temples (id, temple_code, name, state, city, deity, opening_time, closing_time, contact_phone, contact_email, image_url, is_active) VALUES
(1, 'TIRUMALA_VENKATESWARA', 'Tirumala Venkateswara Temple', 'Andhra Pradesh', 'Tirupati', 'Lord Venkateswara (Balaji)', '03:00:00', '23:00:00', '+91 877 2277777', 'helpdesk@tirumala.org', '/images/temples/tirumala.jpg', TRUE),
(2, 'MEENAKSHI_AMMAN', 'Meenakshi Amman Temple', 'Tamil Nadu', 'Madurai', 'Goddess Meenakshi & Lord Sundareswarar', '05:00:00', '22:00:00', '+91 452 2344360', 'info@maduraimeenakshi.org', '/images/temples/meenakshi.jpg', TRUE),
(3, 'SRI_RANGANATHASWAMY', 'Sri Ranganathaswamy Temple', 'Tamil Nadu', 'Srirangam', 'Lord Ranganatha (Maha Vishnu)', '06:00:00', '21:00:00', '+91 431 2432246', 'contact@srirangamtemple.gov.in', '/images/temples/srirangam.jpg', TRUE),
(4, 'KASHI_VISHWANATH', 'Kashi Vishwanath Temple', 'Uttar Pradesh', 'Varanasi', 'Lord Shiva (Vishwanatha Jyotirlinga)', '03:00:00', '23:00:00', '+91 542 2392629', 'shrikashivishwanath@nic.in', '/images/temples/kashi.jpg', TRUE),
(5, 'JAGANNATH_PURI', 'Jagannath Temple', 'Odisha', 'Puri', 'Lord Jagannath, Balabhadra & Subhadra', '05:30:00', '22:30:00', '+91 6752 222002', 'administrator@jagannathtemple.in', '/images/temples/jagannath.jpg', TRUE),
(6, 'SOMNATH_TEMPLE', 'Somnath Temple', 'Gujarat', 'Prabhas Patan', 'Lord Shiva (First Jyotirlinga)', '06:00:00', '22:00:00', '+91 2876 231212', 'info@somnath.org', '/images/temples/somnath.jpg', TRUE),
(7, 'VAISHNO_DEVI', 'Mata Vaishno Devi Shrine', 'Jammu and Kashmir', 'Katra', 'Mata Vaishno Devi (Maha Kali, Lakshmi, Saraswati)', '05:00:00', '23:00:00', '+91 1991 232029', 'helpdesk@maavaishnodevi.net', '/images/temples/vaishnodevi.jpg', TRUE),
(8, 'GOLDEN_TEMPLE', 'Golden Temple (Sri Harmandir Sahib)', 'Punjab', 'Amritsar', 'Sri Guru Granth Sahib Ji', '03:00:00', '23:59:00', '+91 183 2553957', 'info@sgpc.net', '/images/temples/goldentemple.jpg', TRUE)
ON DUPLICATE KEY UPDATE name = VALUES(name), deity = VALUES(deity);

-- 3. Darshan Categories Master
INSERT INTO darshan_types (id, code, name, description, is_active) VALUES
(1, 'SARVA_DARSHAN', 'Sarva Darshan (General Queue)', 'Open complimentary queue available for all visiting devotees.', TRUE),
(2, 'SHEEGHRA_DARSHAN', 'Sheeghra Darshan (Special Entry)', 'Expedited queue with dedicated access counters for comfortable darshan.', TRUE),
(3, 'VIP_SUPRABHATA', 'VIP / Suprabhata Seva', 'Early dawn sanctum awakening ritual with restricted sanctum proximity.', TRUE),
(4, 'DIVYA_PRADAKSHINA', 'Divya Archana & Pradakshina Darshan', 'Special parikrama darshan accompanied by vedic recitations and prasadam.', TRUE)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- 4. Temple-Darshan Rates & Capacity Rules
INSERT INTO temple_darshan (temple_id, darshan_type_id, base_price, max_devotees_per_booking, rules, is_active) VALUES
-- Tirumala
(1, 1, 0.00, 6, 'Traditional South Indian attire required. Dhoti/Kurta or Sari.', TRUE),
(1, 2, 300.00, 6, 'Report at ATC car parking 30 minutes prior to slot.', TRUE),
(1, 3, 1000.00, 4, 'Suprabhata Seva timing 03:00 AM. Traditional dress strictly enforced.', TRUE),
-- Meenakshi Amman
(2, 1, 0.00, 6, 'Free entry through South Tower.', TRUE),
(2, 2, 250.00, 6, 'Express entry via East Tower.', TRUE),
(2, 4, 500.00, 4, 'Includes special kumkum archana and laddu prasadam.', TRUE),
-- Sri Ranganathaswamy
(3, 1, 0.00, 6, 'General darshan via Rajagopuram.', TRUE),
(3, 2, 250.00, 6, 'Fast track darshan ticket at Vaikunta Vasal counter.', TRUE),
(3, 3, 750.00, 4, 'Viswaroopa Seva at 06:00 AM.', TRUE),
-- Kashi Vishwanath
(4, 1, 0.00, 6, 'General queue through Gate 4.', TRUE),
(4, 2, 300.00, 6, 'Sugam Darshan with lounge waiting facility.', TRUE),
(4, 3, 1200.00, 4, 'Mangala Aarti Darshan at 03:00 AM.', TRUE),
-- Jagannath Puri
(5, 1, 0.00, 6, 'Lion Gate (Singhadwara) entry.', TRUE),
(5, 2, 300.00, 6, 'Paramanik Darshan via internal sanctum enclosure.', TRUE),
-- Somnath Temple
(6, 1, 0.00, 6, 'General entry through Digvijay Dwar.', TRUE),
(6, 2, 200.00, 6, 'Special darshan pass with priority queue.', TRUE),
(6, 3, 800.00, 4, 'Maha Shivaratri / Someshwar Puja Pass.', TRUE),
-- Vaishno Devi
(7, 1, 0.00, 6, 'Yatra registration slip mandatory at Banganga.', TRUE),
(7, 2, 500.00, 6, 'Priority Bhawan entry pass with battery car clearance.', TRUE),
(7, 3, 2000.00, 2, 'Aarti darshan inside Holy Cave.', TRUE),
-- Golden Temple
(8, 1, 0.00, 6, 'Open to all faiths. Head must be covered at all times.', TRUE),
(8, 2, 100.00, 6, 'Demonstration voluntary seva booking pass.', TRUE)
ON DUPLICATE KEY UPDATE base_price = VALUES(base_price);

-- 5. Time Slots Configuration
INSERT INTO time_slots (id, temple_id, slot_name, start_time, end_time, is_active) VALUES
-- Tirumala Slots (id 1 - 4)
(1, 1, 'Dawn Brahma Muhurtham Slot', '03:00:00', '06:00:00', TRUE),
(2, 1, 'Morning Suprabhata & Archana Slot', '06:00:00', '10:00:00', TRUE),
(3, 1, 'Mid-Day Sarva Darshan Slot', '11:00:00', '15:00:00', TRUE),
(4, 1, 'Evening Deeparadhana Slot', '17:00:00', '21:00:00', TRUE),
-- Meenakshi Amman Slots (id 5 - 8)
(5, 2, 'Early Morning Thiruvanandal Slot', '05:00:00', '08:30:00', TRUE),
(6, 2, 'Forenoon Uchikala Puja Slot', '09:00:00', '12:30:00', TRUE),
(7, 2, 'Afternoon Sayaratchai Slot', '16:00:00', '18:30:00', TRUE),
(8, 2, 'Night Palliyarai Puja Slot', '19:00:00', '21:30:00', TRUE),
-- Sri Ranganathaswamy Slots (id 9 - 12)
(9, 3, 'Viswaroopa Seva Slot', '06:00:00', '08:30:00', TRUE),
(10, 3, 'Pooja Darshan Slot', '09:00:00', '12:00:00', TRUE),
(11, 3, 'Afternoon Darshan Slot', '14:00:00', '17:30:00', TRUE),
(12, 3, 'Evening Santhanagopalan Slot', '18:00:00', '21:00:00', TRUE),
-- Kashi Vishwanath Slots (id 13 - 16)
(13, 4, 'Mangala Aarti Slot', '03:00:00', '06:00:00', TRUE),
(14, 4, 'Bhog Aarti Slot', '11:00:00', '13:00:00', TRUE),
(15, 4, 'Sandhya Aarti Slot', '17:00:00', '19:30:00', TRUE),
(16, 4, 'Shayan Aarti Slot', '20:30:00', '23:00:00', TRUE),
-- Jagannath Puri Slots (id 17 - 19)
(17, 5, 'Mangala Alati & Mailam Slot', '06:00:00', '10:00:00', TRUE),
(18, 5, 'Madhyanha Dhupa Slot', '12:00:00', '16:00:00', TRUE),
(19, 5, 'Sandhya Alati Slot', '18:00:00', '21:30:00', TRUE),
-- Somnath Slots (id 20 - 22)
(20, 6, 'Pratah Aarti Slot', '07:00:00', '10:30:00', TRUE),
(21, 6, 'Madhyanha Aarti Slot', '12:00:00', '15:30:00', TRUE),
(22, 6, 'Sandhya Aarti & Light Show Slot', '19:00:00', '21:30:00', TRUE),
-- Vaishno Devi Slots (id 23 - 25)
(23, 7, 'Morning Pindiyan Darshan Slot', '06:00:00', '11:00:00', TRUE),
(24, 7, 'Afternoon Holy Cave Path Slot', '12:00:00', '17:00:00', TRUE),
(25, 7, 'Night Divya Aarti Slot', '18:00:00', '22:30:00', TRUE),
-- Golden Temple Slots (id 26 - 28)
(26, 8, 'Palki Sahib Ceremony Slot', '04:00:00', '08:00:00', TRUE),
(27, 8, 'Daytime Gurbani Kirtan Slot', '10:00:00', '16:00:00', TRUE),
(28, 8, 'Night Sukhasan Ceremony Slot', '21:00:00', '23:30:00', TRUE)
ON DUPLICATE KEY UPDATE slot_name = VALUES(slot_name);

-- 6. Slot Inventory Generation (Current Date + 14 Days)
-- Dynamically insert inventory rows for today and next 14 days
INSERT INTO slot_inventory (temple_id, darshan_type_id, slot_id, reservation_date, total_capacity, reserved_count)
SELECT 
    ts.temple_id,
    td.darshan_type_id,
    ts.id AS slot_id,
    DATE_ADD(CURRENT_DATE, INTERVAL d.day_offset DAY) AS reservation_date,
    CASE 
        WHEN td.darshan_type_id = 1 THEN 200 -- General Sarva Darshan
        WHEN td.darshan_type_id = 2 THEN 80  -- Special Entry
        WHEN td.darshan_type_id = 3 THEN 30  -- VIP Suprabhata
        ELSE 50
    END AS total_capacity,
    CASE 
        WHEN d.day_offset = 0 THEN 25
        WHEN d.day_offset = 1 THEN 12
        ELSE 0
    END AS reserved_count
FROM time_slots ts
JOIN temple_darshan td ON ts.temple_id = td.temple_id
CROSS JOIN (
    SELECT 0 AS day_offset UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL
    SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL
    SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL
    SELECT 9 UNION ALL SELECT 10 UNION ALL SELECT 11 UNION ALL
    SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14
) d
WHERE td.is_active = TRUE
ON DUPLICATE KEY UPDATE total_capacity = VALUES(total_capacity);

-- 7. Festival & Special Occasions Master
INSERT INTO festival_events (id, temple_id, festival_name, start_date, end_date, description, is_booking_restricted) VALUES
(1, 1, 'Sri Venkateswara Salakatla Brahmotsavam', DATE_ADD(CURRENT_DATE, INTERVAL 10 DAY), DATE_ADD(CURRENT_DATE, INTERVAL 19 DAY), 'Annual nine-day festival celebrating the Lord on divine vahanas including Garuda Seva.', FALSE),
(2, 2, 'Chithirai Thiruvizha (Celestial Wedding)', DATE_ADD(CURRENT_DATE, INTERVAL 25 DAY), DATE_ADD(CURRENT_DATE, INTERVAL 35 DAY), 'Grand coronation and divine celestial wedding of Goddess Meenakshi with Lord Sundareswarar.', FALSE),
(3, 4, 'Maha Shivaratri Divya Mahotsav', DATE_ADD(CURRENT_DATE, INTERVAL 5 DAY), DATE_ADD(CURRENT_DATE, INTERVAL 7 DAY), 'All-night continuous abhishekam of the Kashi Vishwanath Jyotirlinga with Panchamrit.', FALSE),
(4, 5, 'Rath Yatra (Festival of Chariots)', DATE_ADD(CURRENT_DATE, INTERVAL 40 DAY), DATE_ADD(CURRENT_DATE, INTERVAL 50 DAY), 'The journey of Lord Jagannath, Balabhadra and Subhadra on grand decorated wooden chariots.', FALSE)
ON DUPLICATE KEY UPDATE festival_name = VALUES(festival_name);

-- 8. Demonstration Initial Confirmed Booking
INSERT INTO bookings (
    id, booking_reference, user_id, temple_id, darshan_type_id, slot_id,
    reservation_date, total_devotees, total_amount, booking_status
) VALUES (
    1, 'DY-261030-INIT01', 3, 1, 2, 2,
    CURRENT_DATE, 2, 600.00, 'CONFIRMED'
)
ON DUPLICATE KEY UPDATE booking_reference = VALUES(booking_reference);

INSERT INTO booking_devotees (booking_id, full_name, age, gender, id_proof_type, id_proof_number, token_number) VALUES
(1, 'Gayatri Sundaram', 42, 'FEMALE', 'AADHAAR', '1234-5678-9012', 'TK-TIR-001'),
(1, 'Sundaram Natarajan', 46, 'MALE', 'AADHAAR', '8765-4321-0987', 'TK-TIR-002')
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name);

INSERT INTO payments (booking_id, transaction_reference, payment_method, amount, payment_status) VALUES
(1, 'TXN-INIT-2026103001', 'UPI', 600.00, 'SUCCESS')
ON DUPLICATE KEY UPDATE transaction_reference = VALUES(transaction_reference);
