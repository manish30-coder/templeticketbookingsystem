package com.divyayatra.model;

import java.time.LocalTime;

public class Temple {
    private Long id;
    private String templeCode;
    private String name;
    private String state;
    private String city;
    private String deity;
    private LocalTime openingTime;
    private LocalTime closingTime;
    private String contactPhone;
    private String contactEmail;
    private String imageUrl;
    private boolean active;

    public Temple() {
        this.active = true;
    }

    public Temple(Long id, String templeCode, String name, String state, String city, String deity,
                  LocalTime openingTime, LocalTime closingTime, String contactPhone, String contactEmail,
                  String imageUrl, boolean active) {
        this.id = id;
        this.templeCode = templeCode;
        this.name = name;
        this.state = state;
        this.city = city;
        this.deity = deity;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.contactPhone = contactPhone;
        this.contactEmail = contactEmail;
        this.imageUrl = imageUrl;
        this.active = active;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTempleCode() {
        return templeCode;
    }

    public void setTempleCode(String templeCode) {
        this.templeCode = templeCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDeity() {
        return deity;
    }

    public void setDeity(String deity) {
        this.deity = deity;
    }

    public LocalTime getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(LocalTime openingTime) {
        this.openingTime = openingTime;
    }

    public LocalTime getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(LocalTime closingTime) {
        this.closingTime = closingTime;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
