package com.divyayatra.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.util.List;

public class BookingRequest {
    @NotNull(message = "User ID is required")
    private Long userId;

    @NotNull(message = "Temple ID is required")
    private Long templeId;

    @NotNull(message = "Darshan Type ID is required")
    private Long darshanTypeId;

    @NotNull(message = "Slot ID is required")
    private Long slotId;

    @NotNull(message = "Reservation Date is required")
    private LocalDate reservationDate;

    private String paymentMethod = "UPI";

    @NotEmpty(message = "At least one devotee must be provided")
    @Valid
    private List<DevoteeDto> devotees;

    public BookingRequest() {}

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getTempleId() {
        return templeId;
    }

    public void setTempleId(Long templeId) {
        this.templeId = templeId;
    }

    public Long getDarshanTypeId() {
        return darshanTypeId;
    }

    public void setDarshanTypeId(Long darshanTypeId) {
        this.darshanTypeId = darshanTypeId;
    }

    public Long getSlotId() {
        return slotId;
    }

    public void setSlotId(Long slotId) {
        this.slotId = slotId;
    }

    public LocalDate getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDate reservationDate) {
        this.reservationDate = reservationDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public List<DevoteeDto> getDevotees() {
        return devotees;
    }

    public void setDevotees(List<DevoteeDto> devotees) {
        this.devotees = devotees;
    }
}
