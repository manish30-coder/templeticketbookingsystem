package com.divyayatra.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Booking {
    private Long id;
    private String bookingReference;
    private Long userId;
    private Long templeId;
    private Long darshanTypeId;
    private Long slotId;
    private LocalDate reservationDate;
    private int totalDevotees;
    private BigDecimal totalAmount;
    private String bookingStatus; // PENDING, CONFIRMED, CANCELLED, COMPLETED
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Joined view-friendly properties
    private String templeName;
    private String darshanName;
    private String slotName;
    private String primaryDevoteeName;
    private String userEmail;
    private String userPhone;
    private List<BookingDevotee> devotees = new ArrayList<>();

    public Booking() {
        this.bookingStatus = "PENDING";
        this.totalAmount = BigDecimal.ZERO;
        this.createdAt = LocalDateTime.now();
    }

    public Booking(Long id, String bookingReference, Long userId, Long templeId, Long darshanTypeId,
                   Long slotId, LocalDate reservationDate, int totalDevotees, BigDecimal totalAmount,
                   String bookingStatus) {
        this.id = id;
        this.bookingReference = bookingReference;
        this.userId = userId;
        this.templeId = templeId;
        this.darshanTypeId = darshanTypeId;
        this.slotId = slotId;
        this.reservationDate = reservationDate;
        this.totalDevotees = totalDevotees;
        this.totalAmount = totalAmount;
        this.bookingStatus = bookingStatus;
        this.createdAt = LocalDateTime.now();
    }

    public boolean isEligibleForCancellation() {
        return "CONFIRMED".equalsIgnoreCase(this.bookingStatus) &&
                (this.reservationDate == null || !this.reservationDate.isBefore(LocalDate.now()));
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBookingReference() {
        return bookingReference;
    }

    public void setBookingReference(String bookingReference) {
        this.bookingReference = bookingReference;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getTempleId() {
        return templeId;
    }

    public void setTempleId(Long templeId) {
        this.templeId = templeId;
    }

    public Long getDarshanTypeId() {
        return darshanTypeId;
    }

    public void setDarshanTypeId(Long darshanTypeId) {
        this.darshanTypeId = darshanTypeId;
    }

    public Long getSlotId() {
        return slotId;
    }

    public void setSlotId(Long slotId) {
        this.slotId = slotId;
    }

    public LocalDate getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDate reservationDate) {
        this.reservationDate = reservationDate;
    }

    public int getTotalDevotees() {
        return totalDevotees;
    }

    public void setTotalDevotees(int totalDevotees) {
        this.totalDevotees = totalDevotees;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getTempleName() {
        return templeName;
    }

    public void setTempleName(String templeName) {
        this.templeName = templeName;
    }

    public String getDarshanName() {
        return darshanName;
    }

    public void setDarshanName(String darshanName) {
        this.darshanName = darshanName;
    }

    public String getSlotName() {
        return slotName;
    }

    public void setSlotName(String slotName) {
        this.slotName = slotName;
    }

    public String getPrimaryDevoteeName() {
        return primaryDevoteeName;
    }

    public void setPrimaryDevoteeName(String primaryDevoteeName) {
        this.primaryDevoteeName = primaryDevoteeName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public List<BookingDevotee> getDevotees() {
        return devotees;
    }

    public void setDevotees(List<BookingDevotee> devotees) {
        this.devotees = devotees;
    }
}
