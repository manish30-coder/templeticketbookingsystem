package com.divyayatra.mongodb;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TempleContentMongoRepository extends MongoRepository<TempleContent, String> {
    Optional<TempleContent> findByTempleCode(String templeCode);
    List<TempleContent> findByStateIgnoreCase(String state);
}
