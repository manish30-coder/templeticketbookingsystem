package com.divyayatra.controller;

import com.divyayatra.dto.BookingRequest;
import com.divyayatra.dto.BookingResponse;
import com.divyayatra.dto.CancelBookingRequest;
import com.divyayatra.model.BookingDevotee;
import com.divyayatra.repository.BookingJdbcRepository;
import com.divyayatra.service.CancellationPolicy;
import com.divyayatra.service.ReservationOperation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "*")
public class BookingController {

    private final ReservationOperation reservationOperation;
    private final CancellationPolicy cancellationPolicy;
    private final BookingJdbcRepository bookingRepository;

    public BookingController(ReservationOperation reservationOperation,
                             CancellationPolicy cancellationPolicy,
                             BookingJdbcRepository bookingRepository) {
        this.reservationOperation = reservationOperation;
        this.cancellationPolicy = cancellationPolicy;
        this.bookingRepository = bookingRepository;
    }

    @PostMapping("/reserve")
    public ResponseEntity<BookingResponse> reserveTickets(@Valid @RequestBody BookingRequest request) {
        BookingResponse response = reservationOperation.processReservation(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/cancel")
    public ResponseEntity<Map<String, Object>> cancelBooking(@Valid @RequestBody CancelBookingRequest request) {
        boolean cancelled = cancellationPolicy.processCancellation(request);
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", cancelled);
        resp.put("message", "Booking cancelled successfully and capacity restored.");
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/{reference}")
    public ResponseEntity<Map<String, Object>> getBookingByReference(@PathVariable String reference) {
        Map<String, Object> booking = bookingRepository.findDetailedBookingByReference(reference)
                .orElse(null);
        if (booking == null) {
            return ResponseEntity.notFound().build();
        }
        Long bookingId = (Long) booking.get("booking_id");
        List<BookingDevotee> devotees = bookingRepository.findDevoteesForBooking(bookingId);

        Map<String, Object> response = new HashMap<>(booking);
        response.put("devotees", devotees);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Map<String, Object>>> getBookingsByUser(@PathVariable Long userId) {
        List<Map<String, Object>> bookings = bookingRepository.findDetailedBookingsByUserId(userId);
        return ResponseEntity.ok(bookings);
    }
}
