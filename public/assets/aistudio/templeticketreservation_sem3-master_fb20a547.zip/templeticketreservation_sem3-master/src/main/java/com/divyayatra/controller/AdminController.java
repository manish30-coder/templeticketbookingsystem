package com.divyayatra.controller;

import com.divyayatra.model.AbstractUser;
import com.divyayatra.model.Temple;
import com.divyayatra.repository.BookingJdbcRepository;
import com.divyayatra.repository.SlotInventoryJdbcRepository;
import com.divyayatra.repository.TempleJdbcRepository;
import com.divyayatra.repository.UserJdbcRepository;
import com.divyayatra.service.TempleService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final BookingJdbcRepository bookingRepository;
    private final TempleService templeService;
    private final TempleJdbcRepository templeJdbcRepository;
    private final SlotInventoryJdbcRepository slotInventoryRepository;
    private final UserJdbcRepository userRepository;

    public AdminController(BookingJdbcRepository bookingRepository,
                           TempleService templeService,
                           TempleJdbcRepository templeJdbcRepository,
                           SlotInventoryJdbcRepository slotInventoryRepository,
                           UserJdbcRepository userRepository) {
        this.bookingRepository = bookingRepository;
        this.templeService = templeService;
        this.templeJdbcRepository = templeJdbcRepository;
        this.slotInventoryRepository = slotInventoryRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> getDashboardMetrics() {
        return ResponseEntity.ok(bookingRepository.getOverallMetrics());
    }

    @GetMapping("/revenue-stats")
    public ResponseEntity<List<Map<String, Object>>> getRevenueStats() {
        return ResponseEntity.ok(bookingRepository.getTempleRevenueStats());
    }

    @GetMapping("/temples")
    public ResponseEntity<List<Temple>> getAllTemples() {
        return ResponseEntity.ok(templeJdbcRepository.findAllAdmin());
    }

    @PostMapping("/temples")
    public ResponseEntity<Map<String, Object>> addTemple(@RequestBody Temple temple) {
        Long id = templeService.addTemple(temple);
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", true);
        resp.put("templeId", id);
        resp.put("message", "New temple successfully listed.");
        return ResponseEntity.ok(resp);
    }

    @PutMapping("/temples")
    public ResponseEntity<Map<String, Object>> updateTemple(@RequestBody Temple temple) {
        boolean updated = templeService.updateTemple(temple);
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", updated);
        resp.put("message", "Temple details updated.");
        return ResponseEntity.ok(resp);
    }

    @DeleteMapping("/temples/{id}")
    public ResponseEntity<Map<String, Object>> deleteTemple(@PathVariable Long id) {
        boolean deleted = templeService.deleteTemple(id);
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", deleted);
        resp.put("message", "Temple deactivated.");
        return ResponseEntity.ok(resp);
    }

    @PutMapping("/slots/capacity")
    public ResponseEntity<Map<String, Object>> updateSlotCapacity(
            @RequestParam Long inventoryId,
            @RequestParam int newCapacity) {
        boolean updated = slotInventoryRepository.updateCapacity(inventoryId, newCapacity);
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", updated);
        resp.put("message", "Slot capacity updated to " + newCapacity);
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/slots/configure")
    public ResponseEntity<Map<String, Object>> configureSlot(
            @RequestParam Long templeId,
            @RequestParam Long darshanTypeId,
            @RequestParam Long slotId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam int capacity) {
        boolean created = slotInventoryRepository.createOrUpdateInventory(templeId, darshanTypeId, slotId, date, capacity);
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", created);
        resp.put("message", "Slot inventory configured.");
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/users")
    public ResponseEntity<List<AbstractUser>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }
}
