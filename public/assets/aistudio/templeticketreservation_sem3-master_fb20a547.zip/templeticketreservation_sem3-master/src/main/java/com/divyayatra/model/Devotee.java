package com.divyayatra.model;

/**
 * Devotee domain model representing visiting pilgrims.
 * Demonstrates Unit II: Inheritance, method overriding, super() invocation.
 */
public class Devotee extends AbstractUser {
    private String idProofType;
    private String idProofNumber;

    public Devotee() {
        super();
        this.role = UserRole.DEVOTEE;
    }

    public Devotee(Long id, String fullName, String email, String phone, String passwordHash,
                   String idProofType, String idProofNumber) {
        super(id, fullName, email, phone, passwordHash, UserRole.DEVOTEE);
        this.idProofType = idProofType;
        this.idProofNumber = idProofNumber;
    }

    @Override
    public String getDashboardRoute() {
        return "/pages/devotee_dashboard.html";
    }

    public String getIdProofType() {
        return idProofType;
    }

    public void setIdProofType(String idProofType) {
        this.idProofType = idProofType;
    }

    public String getIdProofNumber() {
        return idProofNumber;
    }

    public void setIdProofNumber(String idProofNumber) {
        this.idProofNumber = idProofNumber;
    }
}
