package com.divyayatra.service;

import com.divyayatra.exception.DivyaYatraException;
import com.divyayatra.model.Temple;
import com.divyayatra.model.TimeSlot;
import com.divyayatra.mongodb.FestivalAnnouncement;
import com.divyayatra.mongodb.FestivalAnnouncementMongoRepository;
import com.divyayatra.mongodb.TempleContent;
import com.divyayatra.mongodb.TempleContentMongoRepository;
import com.divyayatra.repository.SlotInventoryJdbcRepository;
import com.divyayatra.repository.TempleJdbcRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class TempleService {

    private final TempleJdbcRepository templeJdbcRepository;
    private final SlotInventoryJdbcRepository slotInventoryJdbcRepository;
    private final TempleContentMongoRepository templeContentMongoRepository;
    private final FestivalAnnouncementMongoRepository festivalAnnouncementMongoRepository;

    public TempleService(TempleJdbcRepository templeJdbcRepository,
                         SlotInventoryJdbcRepository slotInventoryJdbcRepository,
                         TempleContentMongoRepository templeContentMongoRepository,
                         FestivalAnnouncementMongoRepository festivalAnnouncementMongoRepository) {
        this.templeJdbcRepository = templeJdbcRepository;
        this.slotInventoryJdbcRepository = slotInventoryJdbcRepository;
        this.templeContentMongoRepository = templeContentMongoRepository;
        this.festivalAnnouncementMongoRepository = festivalAnnouncementMongoRepository;
    }

    public List<Temple> getAllTemples() {
        return templeJdbcRepository.findAll();
    }

    public List<Temple> getTemplesByState(String state) {
        if (state == null || state.isBlank() || "ALL".equalsIgnoreCase(state)) {
            return templeJdbcRepository.findAll();
        }
        return templeJdbcRepository.findByState(state);
    }

    public List<String> getAllStates() {
        return templeJdbcRepository.findAllDistinctStates();
    }

    /**
     * Aggregates structured relational data from MySQL with rich unstructured lore from MongoDB.
     * Demonstrates Polyglot Persistence (MySQL + MongoDB) in Unit V.
     */
    public Map<String, Object> getTempleFullDetails(Long templeId) {
        Temple temple = templeJdbcRepository.findById(templeId)
                .orElseThrow(() -> new DivyaYatraException("Temple not found with id: " + templeId, 404));

        Map<String, Object> response = new HashMap<>();
        response.put("temple", temple);

        // Fetch darshan categories and prices from MySQL
        List<Map<String, Object>> darshans = templeJdbcRepository.getDarshanTypesForTemple(templeId);
        response.put("darshanTypes", darshans);

        // Fetch time slots from MySQL
        List<TimeSlot> slots = templeJdbcRepository.getTimeSlotsForTemple(templeId);
        response.put("timeSlots", slots);

        // Fetch rich narrative lore, rituals, and dress code from MongoDB
        Optional<TempleContent> mongoContent = templeContentMongoRepository.findByTempleCode(temple.getTempleCode());
        mongoContent.ifPresent(content -> response.put("culturalLore", content));

        // Fetch festival circulars from MongoDB
        List<FestivalAnnouncement> announcements = festivalAnnouncementMongoRepository.findByTempleCode(temple.getTempleCode());
        response.put("festivals", announcements);

        return response;
    }

    public List<Map<String, Object>> getLiveAvailability(Long templeId, LocalDate date) {
        return slotInventoryJdbcRepository.findLiveAvailability(templeId, date);
    }

    public Long addTemple(Temple temple) {
        return templeJdbcRepository.save(temple);
    }

    public boolean updateTemple(Temple temple) {
        return templeJdbcRepository.update(temple);
    }

    public boolean deleteTemple(Long id) {
        return templeJdbcRepository.delete(id);
    }
}
