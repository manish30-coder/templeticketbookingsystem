package com.divyayatra;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class DatabaseConnectionTest {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired(required = false)
    private MongoTemplate mongoTemplate;

    @Test
    @DisplayName("Verify MySQL JDBC Connection and Query Execution")
    void testMySqlConnection() {
        assertNotNull(jdbcTemplate, "JdbcTemplate should be configured and injected");
        Integer result = jdbcTemplate.queryForObject("SELECT 1", Integer.class);
        assertEquals(1, result, "MySQL query SELECT 1 should return 1");
    }

    @Test
    @DisplayName("Verify MongoDB Connection and Collection Access")
    void testMongoConnection() {
        assertNotNull(mongoTemplate, "MongoTemplate should be configured and injected");
        String dbName = mongoTemplate.getDb().getName();
        assertEquals("divyayatra_content_db", dbName, "MongoDB connected database name should match configuration");
    }
}
